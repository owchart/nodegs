/*****************************************************************************\
*                                                                             *
* Str.cs -    Str functions, types, and definitions                           *
*                                                                             *
*               Version 1.00 ������                                       *
*                                                                             *
*               Copyright (c) 2016-2016, Client. All rights reserved.         *
*               Created by Lord.                                              *
*                                                                             *
*******************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Newtonsoft.Json;

namespace LordStockAT
{
    public class CStrA
    {
        /// <summary>
        /// ����Ʊ����ת��Ϊ�ɽ�����
        /// </summary>
        /// <param name="code">��Ʊ����</param>
        /// <returns>���˴���</returns>
        public static String ConvertDBCodeToDealCode(String code)
        {
            String securityCode = code;
            int index = securityCode.IndexOf(".");
            if (index > 0)
            {
                securityCode = securityCode.Substring(0, index);
            }
            return securityCode;
        }

        /// <summary>
        /// ��ȡ֤ȯ���ļ�����
        /// </summary>
        /// <param name="code">����</param>
        /// <returns>�ļ�����</returns>
        public static String ConvertDBCodeToFileName(String code)
        {
            String fileName = code;
            if (fileName.IndexOf(".") != -1)
            {
                fileName = fileName.Substring(fileName.IndexOf('.') + 1) + fileName.Substring(0, fileName.IndexOf('.'));
            }
            fileName += ".txt";
            return fileName;
        }

        /// <summary>
        /// ����Ʊ����ת��Ϊ���˴���
        /// </summary>
        /// <param name="code">��Ʊ����</param>
        /// <returns>���˴���</returns>
        public static String ConvertDBCodeToSinaCode(String code)
        {
            String securityCode = code;
            int index = securityCode.IndexOf(".SH");
            if (index > 0)
            {
                securityCode = "sh" + securityCode.Substring(0, securityCode.IndexOf("."));
            }
            else
            {
                securityCode = "sz" + securityCode.Substring(0, securityCode.IndexOf("."));
            }
            return securityCode;
        }

        /// <summary>
        /// �ַ���ת��Ϊ������
        /// </summary>
        /// <param name="str">�ַ���</param>
        /// <returns>��ֵ</returns>
        public static double ConvertStrToDouble(String str)
        {
            double value = 0;
            double.TryParse(str, out value);
            return value;
        }

        /// <summary>
        /// �ַ���ת��Ϊ������
        /// </summary>
        /// <param name="str">�ַ���</param>
        /// <returns>��ֵ</returns>
        public static float ConvertStrToFloat(String str)
        {
            float value = 0;
            float.TryParse(str, out value);
            return value;
        }

        /// <summary>
        /// �ַ���ת��Ϊ����
        /// </summary>
        /// <param name="str">�ַ���</param>
        /// <returns>��ֵ</returns>
        public static int ConvertStrToInt(String str)
        {
            int value = 0;
            int.TryParse(str, out value);
            return value;
        }

        /// <summary>
        /// �����л�JSON����������������.
        /// </summary>
        /// <typeparam name="T">������������</typeparam>
        /// <param name="json">json�ַ���</param>
        /// <param name="anonymousTypeObject">��������</param>
        /// <returns>��������</returns>
        public static T DeserializeAnonymousType<T>(string json, T anonymousTypeObject)
        {
            T t = JsonConvert.DeserializeAnonymousType(json, anonymousTypeObject);
            return t;
        }

        /// <summary>
        /// ����JSON�������ɶ���ʵ�弯��
        /// </summary>
        /// <typeparam name="T">��������</typeparam>
        /// <param name="json">json�����ַ���(eg.[{"ID":"112","Name":"ʯ�Ӷ�"}])</param>
        /// <returns>����ʵ�弯��</returns>
        public static List<T> DeserializeJsonToList<T>(string json) where T : class
        {
            JsonSerializer serializer = new JsonSerializer();
            StringReader sr = new StringReader(json);
            object o = serializer.Deserialize(new JsonTextReader(sr), typeof(List<T>));
            List<T> list = o as List<T>;
            return list;
        }

        /// <summary>
        /// ����JSON�ַ������ɶ���ʵ��
        /// </summary>
        /// <typeparam name="T">��������</typeparam>
        /// <param name="json">json�ַ���(eg.{"ID":"112","Name":"ʯ�Ӷ�"})</param>
        /// <returns>����ʵ��</returns>
        public static T DeserializeJsonToObject<T>(string json) where T : class
        {
            JsonSerializer serializer = new JsonSerializer();
            StringReader sr = new StringReader(json);
            object o = serializer.Deserialize(new JsonTextReader(sr), typeof(T));
            T t = o as T;
            return t;
        }

        /// <summary>
        /// ��ȡ���ݿ�ת���ַ���
        /// </summary>
        /// <param name="str">�ַ���</param>
        /// <returns>ת���ַ���</returns>
        public static String GetDBString(String str)
        {
            return str.Replace("'", "''");
        }

        /// <summary>
        /// ��ȡGuid
        /// </summary>
        /// <returns></returns>
        public static String GetGuid()
        {
            return Guid.NewGuid().ToString();
        }

        /// <summary>
        /// ���������л�ΪJSON��ʽ
        /// </summary>
        /// <param name="o">����</param>
        /// <returns>json�ַ���</returns>
        public static string SerializeObject(object o)
        {
            string json = JsonConvert.SerializeObject(o);
            return json;
        }
    }
}
