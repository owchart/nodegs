using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;
using System.IO;
using OwLib;
using System.Runtime.InteropServices;
using System.Text;

namespace LordStockAT
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(String[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            DataCenter.StartService();

            Application.ThreadException += new ThreadExceptionEventHandler(Application_ThreadException);
            if (args == null || args.Length == 0)
            {
                MainForm mainForm = new MainForm();
                mainForm.Load("MainFrame");
                Application.Run(mainForm);
            }
        }

        static void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
        {
            Console.WriteLine("1");
        }
    }
}