﻿using OwLib;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;

namespace LordStockAT
{
    /// <summary>
    /// 行情系统
    /// </summary>
    public class OwChart
    {
        #region Lord 2016/12/24
        /// <summary>
        /// 创建行情系统
        /// </summary>
        public OwChart(MainFrame mainFrame)
        {
            m_mainFrame = mainFrame;
            InitInterface();
        }

        /// <summary>
        /// 所有的层
        /// </summary>
        private List<CDiv> m_divs = new List<CDiv>();

        /// <summary>
        /// 历史数据
        /// </summary>
        private List<HistoryMinuteQuoteInfo> m_historyMinuteQuoteInfos = new List<HistoryMinuteQuoteInfo>();

        /// <summary>
        /// 历史数据索引
        /// </summary>
        private int m_historyMinuteQuoteInfoIndex = -1;

        /// <summary>
        /// 横轴的步长
        /// </summary>
        private List<double> m_hScaleSteps = new List<double>();

        /// <summary>
        /// 是否调试模式
        /// </summary>
        private bool m_isDebugMode = false;

        /// <summary>
        /// 实时数据面板
        /// </summary>
        private LatestDiv m_latestDiv;

        /// <summary>
        /// 行情服务
        /// </summary>
        private QuoteService m_quoteService;

        /// <summary>
        /// 请求编号
        /// </summary>
        private int m_requestID = BaseService.GetRequestID();

        /// <summary>
        /// 股票服务
        /// </summary>
        private SecurityServiceEx m_securityService;

        /// <summary>
        /// 读取数据的timer
        /// </summary>
        private System.Timers.Timer m_timer = null;

        private ChartA m_chart;

        /// <summary>
        /// 获取或设置图形控件
        /// </summary>
        public ChartA Chart
        {
            get { return m_chart; }
            set { m_chart = value; }
        }

        private int m_digit = 2;

        /// <summary>
        /// 获取或设置价格保留小数位数
        /// </summary>
        public int Digit
        {
            get { return m_digit; }
            set { m_digit = value; }
        }

        private int m_index = -1;

        /// <summary>
        /// 获取当前实际的数据索引
        /// </summary>
        public int Index
        {
            get { return m_index; }
        }

        private MainFrame m_mainFrame = null;

        /// <summary>
        /// 获取或者设置主Frame
        /// </summary>
        public MainFrame MainFrame
        {
            get { return m_mainFrame; }
            set { m_mainFrame = value; }
        }

        private Security m_searchSecurity;
        /// <summary>
        /// 获取或者设置显示的证券信息
        /// </summary>
        public Security SearchSecurity
        {
            get { return m_searchSecurity;  }
            set  {  m_searchSecurity = value; }
        }

        /// <summary>
        /// 销毁资源方法
        /// </summary>
        public void Dispose()
        {
            m_quoteService.StopPushHistoryDatas(m_requestID);
            m_quoteService.UnRegisterListener(m_requestID);
        }

        /// <summary>
        /// 退出程序
        /// </summary>
        public void Exit()
        {
            Thread.Sleep(2000);
            DataCenter.DisConnect();
        }

        /// <summary>
        /// 初始化图形界面
        /// </summary>
        private void InitInterface()
        {
            #region 删除K线
            /*
            m_chart = m_mainFrame.GetChart("divKLine");

            CTable dataSource = m_chart.DataSource;
            m_chart.RegisterEvent(new ControlInvokeEvent(ChartInvoke), EVENTID.INVOKE);
            m_chart.RegisterEvent(new ControlMouseEvent(ChartMouseDown), EVENTID.MOUSEDOWN);
            m_chart.RegisterEvent(new ControlMouseEvent(ChartMouseMove), EVENTID.MOUSEMOVE);
            m_chart.RegisterEvent(new ControlMouseEvent(ChartMouseUp), EVENTID.MOUSEUP);
            m_chart.BackColor = CDraw.PCOLORS_BACKCOLOR4;
            m_chart.BorderColor = CDraw.PCOLORS_LINECOLOR2;
            //设置可以拖动K线，成交量，线及标记
            m_chart.CanMoveShape = true;
            //设置滚动加速
            m_chart.ScrollAddSpeed = true;
            //设置左右Y轴的宽度
            m_chart.LeftVScaleWidth = 15;
            m_chart.RightVScaleWidth = 15;
            //设置X轴刻度间距
            m_chart.HScalePixel = 3;
            //设置X轴
            m_chart.HScaleFieldText = "日期";
            //添加k线层
            m_candleDiv = m_chart.AddDiv(60);
            m_candleDiv.BackColor = CDraw.PCOLORS_BACKCOLOR4;
            m_candleDiv.TitleBar.Text = "分时线";
            //设置主Div左右Y轴数值带下划线
            m_candleDiv.VGrid.Visible = true;
            m_candleDiv.LeftVScale.NumberStyle = NumberStyle.UnderLine;
            m_candleDiv.LeftVScale.MarginTop = 2;
            m_candleDiv.LeftVScale.MarginBottom = 2;
            m_candleDiv.LeftVScale.Font = new FONT("Arial", 14, false, false, false);
            m_candleDiv.RightVScale.NumberStyle = NumberStyle.UnderLine;
            m_candleDiv.RightVScale.Font = new FONT("Arial", 14, false, false, false);
            m_candleDiv.RightVScale.MarginTop = 2;
            m_candleDiv.RightVScale.MarginBottom = 2;
            CTitle priceTitle = new CTitle(KeyFields.CLOSE_INDEX, "", CDraw.PCOLORS_FORECOLOR9, 2, true);
            priceTitle.FieldTextMode = TextMode.Value;
            m_candleDiv.TitleBar.Titles.Add(priceTitle);
            //添加K线图
            m_candle = new CandleShape();
            m_candleDiv.AddShape(m_candle);
            m_candle.CloseField = KeyFields.CLOSE_INDEX;
            m_candle.HighField = KeyFields.HIGH_INDEX;
            m_candle.LowField = KeyFields.LOW_INDEX;
            m_candle.OpenField = KeyFields.OPEN_INDEX;
            m_candle.CloseFieldText = "收盘";
            m_candle.HighFieldText = "最高";
            m_candle.LowFieldText = "最低";
            m_candle.OpenFieldText = "开盘";
            m_candle.Visible = false;
            //分时线
            m_minuteLine = new PolylineShape();
            m_candleDiv.AddShape(m_minuteLine);
            m_minuteLine.Color = CDraw.PCOLORS_LINECOLOR;
            m_minuteLine.FieldName = KeyFields.CLOSE_INDEX;
            //分时线的平均线
            m_minuteAvgLine = new PolylineShape();
            m_candleDiv.AddShape(m_minuteAvgLine);
            m_minuteAvgLine.Color = CDraw.PCOLORS_LINECOLOR2;
            m_minuteAvgLine.FieldName = KeyFields.AVGPRICE_INDEX;
            //添加指标层
            CDiv indDiv = m_chart.AddDiv(25);
            indDiv.BackColor = CDraw.PCOLORS_BACKCOLOR4;
            indDiv.VGrid.Distance = 40;
            indDiv.LeftVScale.MarginTop = 2;
            indDiv.LeftVScale.MarginBottom = 2;
            indDiv.LeftVScale.Font = new FONT("Arial", 14, false, false, false);
            indDiv.RightVScale.MarginTop = 2;
            indDiv.RightVScale.MarginBottom = 2;
            indDiv.RightVScale.Font = new FONT("Arial", 14, false, false, false);
            //设置X轴不可见
            m_candleDiv.HScale.Visible = false;
            m_candleDiv.HScale.Height = 0;
            indDiv.HScale.Visible = true;
            indDiv.HScale.Height = 22;
            //设置坐标轴的颜色
            indDiv.LeftVScale.ForeColor = CDraw.PCOLORS_FORECOLOR;
            indDiv.RightVScale.ForeColor = CDraw.PCOLORS_FORECOLOR;
            //设置坐标轴的网格线间隔
            //添加到集合
            m_divs.AddRange(new CDiv[] { m_candleDiv, indDiv });
            添加用户自定义层
            m_floatDiv = m_mainFrame.FindControl("divFloat") as FloatDiv;
            m_floatDiv.Chart = this;
            dataSource.AddColumn(KeyFields.CLOSE_INDEX);
            dataSource.AddColumn(KeyFields.HIGH_INDEX);
            dataSource.AddColumn(KeyFields.LOW_INDEX);
            dataSource.AddColumn(KeyFields.OPEN_INDEX);
            dataSource.AddColumn(KeyFields.VOL_INDEX);
            dataSource.AddColumn(KeyFields.AMOUNT_INDEX);
            dataSource.AddColumn(KeyFields.AVGPRICE_INDEX);
            dataSource.SetColsCapacity(16);
            dataSource.SetColsGrowStep(4);
            */
            #endregion

            //当前数据层
            m_latestDiv = m_mainFrame.FindControl("divLatest") as LatestDiv;
            m_latestDiv.Chart = this;
            m_quoteService = DataCenter.QuoteService;
            m_securityService = DataCenter.SecurityService;

            DataCenter.HistoryMinuteQuoteService.GetHistoryMinuteQuoteInfos(m_historyMinuteQuoteInfos);
            m_historyMinuteQuoteInfoIndex = -1;

            m_timer = new System.Timers.Timer(1000);
            m_timer.Elapsed += Timer_TimesUp;
            m_timer.AutoReset = true; //每到指定时间Elapsed事件是触发一次（false），还是一直触发（true）
            m_timer.Start();
        }

        /// <summary>
        /// 是否有窗体显示
        /// </summary>
        /// <returns>是否显示</returns>
        public bool IsWindowShowing()
        {
            List<ControlA> controls = m_mainFrame.Native.GetControls();
            int controlsSize = controls.Count;
            for (int i = 0; i < controlsSize; i++)
            {
                WindowFrameA frame = controls[i] as WindowFrameA;
                if (frame != null)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 加载数据
        /// </summary>
        public void LoadData()
        {
            InitInterface();
        }

        /// <summary>
        /// 行情数据回调
        /// </summary>
        /// <param name="message">消息</param>
        private void QuoteDataCallBack(CMessage message)
        {
            if (message.m_bodyLength > 0)
            {
                //OnQuoteDataCallBack(message);
            }
        }

        /// <summary>
        /// 重置缩放尺寸
        /// </summary>
        /// <param name="clientSize">客户端大小</param>
        public void ResetScaleSize(SIZE clientSize)
        {
            if (m_mainFrame.Native != null)
            {
                ControlHost host = m_mainFrame.Native.Host;
                SIZE nativeSize = m_mainFrame.Native.DisplaySize;
                List<ControlA> controls = m_mainFrame.Native.GetControls();
                int controlsSize = controls.Count;
                for (int i = 0; i < controlsSize; i++)
                {
                    WindowFrameA frame = controls[i] as WindowFrameA;
                    if (frame != null)
                    {
                        WindowEx window = frame.GetControls()[0] as WindowEx;
                        if (window != null && !window.AnimateMoving)
                        {
                            POINT location = window.Location;
                            if (location.x < 10 || location.x > nativeSize.cx - 10)
                            {
                                location.x = 0;
                            }
                            if (location.y < 30 || location.y > nativeSize.cy - 30)
                            {
                                location.y = 0;
                            }
                            window.Location = location;
                        }
                    }
                }
                m_mainFrame.Native.ScaleSize = new SIZE((int)(clientSize.cx * 1), (int)(clientSize.cy * 1));
                m_mainFrame.Native.Update();
            }
        }

        /// <summary>
        /// 显示提示窗口
        /// </summary>
        /// <param name="text">文本</param>
        /// <param name="caption">标题</param>
        /// <param name="uType">格式</param>
        /// <returns>结果</returns>
        public int ShowMessageBox(String text, String caption, int uType)
        {
            MessageBox.Show(text, caption);
            return 1;
        }
        
        /// <summary>
        /// 定时拉取数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Timer_TimesUp(object sender, System.Timers.ElapsedEventArgs e)
        {
            if(m_searchSecurity == null || m_searchSecurity.m_code == null || m_searchSecurity.m_code.Length == 0)
            {
                return;
            }

            if (m_isDebugMode)
            {
                int size = m_historyMinuteQuoteInfos.Count;
                if (size == 0)
                {
                    return;
                }

                if (m_historyMinuteQuoteInfoIndex >= size - 1)
                {
                    m_historyMinuteQuoteInfoIndex = -1;
                }

                m_historyMinuteQuoteInfoIndex++;
                HistoryMinuteQuoteInfo quoteInfo = m_historyMinuteQuoteInfos[m_historyMinuteQuoteInfoIndex];
                SecurityLatestData latestData = new SecurityLatestData();
                latestData = CStrA.DeserializeJsonToObject<SecurityLatestData>(quoteInfo.m_quoteInfo);
                m_latestDiv.BeginInvoke(latestData);
                m_mainFrame.DealStrategy(latestData);
                return;
            }

            DateTime dtNow = DateTime.Now;
            if (dtNow.DayOfWeek == DayOfWeek.Saturday || dtNow.DayOfWeek == DayOfWeek.Sunday)
            {
                return;
            }
            if (dtNow.Hour < 9 || (dtNow.Hour == 9 && dtNow.Minute < 30))
            {
                return;
            }
            if (dtNow.Hour > 15 || (dtNow.Hour == 15 && dtNow.Minute > 0))
            {
                return;
            }
            if (dtNow.Hour == 11 && dtNow.Minute > 30)
            {
                return;
            }
            if (dtNow.Hour == 12 && dtNow.Minute <= 59)
            {
                return;
            }

            String sinaCode = CStrA.ConvertDBCodeToSinaCode(m_searchSecurity.m_code);
            String url = String.Format("http://hq.sinajs.cn/list={0}", sinaCode);
            String html = DataCenter.GetHttpWebRequest(url, "GB2312");
            if (html != null && html.Length > 0)
            {
                String preKey = String.Format("var hq_str_{0}=\"", sinaCode);
                html = html.Replace(preKey, "");

                SecurityLatestData latestData = SecurityLatestData.ConvertToSecurityLatestData(m_searchSecurity.m_code, html);
                if (latestData == null)
                {
                    return;
                }
                HistoryMinuteQuoteInfo quoteInfo = HistoryMinuteQuoteInfo.ConvertToHistoryMinuteQuoteInfo(latestData);
                m_latestDiv.BeginInvoke(latestData);
                m_mainFrame.DealStrategy(latestData);

                if (DataCenter.HistoryMinuteQuoteService.GetHistoryMinuteQuoteInfoCount(quoteInfo) == 0)
                {
                    DataCenter.HistoryMinuteQuoteService.AddHistoryMinuteQuoteInfo(quoteInfo);
                }
                html = null;
            }
        }
        #endregion
    }
}
