/*****************************************************************************\
*                                                                             *
* MainFrame.cs -  MainFrame functions, types, and definitions.                *
*                                                                             *
*               Version 1.00  ����                                          *
*                                                                             *
*               Copyright (c) 2016-2016, Piratecat. All rights reserved.      *
*               Created by Lord 2016/12/24.                                   *
*                                                                             *
******************************************************************************/

using System;
using System.Collections.Generic;
using OwLib;
using System.Windows.Forms;
using System.Threading;

namespace LordStockAT
{
    /// <summary>
    /// ����ϵͳ
    /// </summary>
    public class MainFrame : UIXmlEx, IDisposable
    {
        /// <summary>
        /// ��������ϵͳ
        /// </summary>
        public MainFrame()
        {
        }

        // �ֲ��ֵ�
        private IDictionary<String, SecurityPosition> m_dictSecurityPositions = new Dictionary<String, SecurityPosition>();

        // ί�б���
        private GridA m_gridCommissionAccount;
        // �ֱֲ���
        private GridA m_gridPositionAccount;
        // �ɽ�����
        private GridA m_gridTradeAccount;
        // �Ƿ�����
        private bool m_isStart = false;
        // �������
        private OwChart m_owChart = null;

        // ��ǰִ�еĽ��ײ���
        private SecurityStrategySetting m_securityStrategySettingCurrnet = null;
        // ���ײ���
        private List<SecurityStrategySetting> m_securityStrategySettings = new List<SecurityStrategySetting>();
        // �˻���Ϣ
        private SecurityTradingAccount m_securityTradingAccount = null;
        // �ϴ�ί����û�гɽ��ļ۸�
        private float m_lastCommissionNoTradePrice = 0;

        /// <summary>
        /// ����¼�
        /// </summary>
        /// <param name="sender">������</param>
        /// <param name="mp">����</param>
        /// <param name="button">��ť</param>
        /// <param name="clicks">�������</param>
        /// <param name="delta">����ֵ/param>
        private void ClickEvent(object sender, POINT mp, MouseButtonsA button, int clicks, int delta)
        {
            if (button == MouseButtonsA.Left && clicks == 1)
            {
                ControlA control = sender as ControlA;
                String name = control.Name;
                if (name == "btnStart")
                {
                    LoadData();
                }
                else if (name == "btnSetStrategy")
                {
                    ShowStrategySettingWindow();
                }          
            }
        }

        /// <summary>
        /// ִ�в���
        /// </summary>
        /// <param name="latestData">��������</param>
        public void DealStrategy(SecurityLatestData latestData)
        {
            if (!m_isStart)
            {
                return;
            }

            Thread deadThread = new Thread(new ParameterizedThreadStart(DealStrategyThread));
            deadThread.IsBackground = true;
            deadThread.Start(latestData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="param"></param>
        public void DealStrategyThread(object param)
        {
            SecurityLatestData latestData = param as SecurityLatestData;
            if(latestData == null)
            {
                return;
            }

            if (m_securityStrategySettingCurrnet == null || m_securityStrategySettingCurrnet.m_strategyType != 0)
            {
                return;
            }

            SecurityRangeTradeCondition securityRangeTradeCondition
                = CStrA.DeserializeJsonToObject<SecurityRangeTradeCondition>(m_securityStrategySettingCurrnet.m_strategySettingInfo);
            if (securityRangeTradeCondition == null)
            {
                return;
            }

            bool isInitBuild = securityRangeTradeCondition.m_initBuildFlag;
            float bottomRangePrice = securityRangeTradeCondition.m_bottomRangePrice;
            float topRangePrice = securityRangeTradeCondition.m_topRangePrice;
            // ��ǰ�۸񳬹�����������޼۸���ߵ�����������ޣ���������
            if (latestData.m_close > topRangePrice || latestData.m_close < bottomRangePrice)
            {
                return;
            }
            // �Ѿ��������
            if (isInitBuild)
            {
                bool isBasePrice = securityRangeTradeCondition.m_isBasePrice;
                float lastDealPrice = securityRangeTradeCondition.m_lastDealPrice;
                int buyCount = securityRangeTradeCondition.m_buyCount;
                int sellCount = securityRangeTradeCondition.m_sellCount;
                float lowLastDealBuy = securityRangeTradeCondition.m_lowLastDealBuy;
                float overLastDealSell = securityRangeTradeCondition.m_overLastDealSell;
                bool isCrossBuy = securityRangeTradeCondition.m_isCrossBuy;
                bool isCrossSell = securityRangeTradeCondition.m_isCrossSell;

                // ��ǰ�۸���ϴ�ί��δ�ɽ��۸�ıȽ�
                float diffPrice1 = latestData.m_close - m_lastCommissionNoTradePrice;
                if(diffPrice1 == 0)
                {
                    return;
                }
                if(diffPrice1 > 0 && diffPrice1 < overLastDealSell)
                {
                    return;
                }
                if(diffPrice1 < 0 && Math.Abs(diffPrice1) < lowLastDealBuy)
                {
                    return;
                }

                // ���㵱ǰ�۸���ϴγɽ��۸�Ĳ�ֵ
                float diffPrice = latestData.m_close - lastDealPrice;
                if (diffPrice > 0)
                {
                    SecurityPosition postion = null;
                    if (!m_dictSecurityPositions.TryGetValue(latestData.m_securityCode, out postion))
                    {
                        // û�гֲ���Ϣ����������
                        return;
                    }

                    // �����ϴγɽ��۸�
                    int readSellCount = 0;
                    int sepaCount = (int)(diffPrice / overLastDealSell);
                    if(sepaCount < 1)
                    {
                        // �۸�û�дﵽԤ��ֵ
                        return;
                    }
                    if (isCrossSell)
                    {
                        readSellCount = sepaCount * sellCount;
                    }
                    else
                    {
                        readSellCount = sellCount;
                    }

                    if(readSellCount < 100)
                    {
                        return;
                    }

                    // ��Ʊ���С�ڿ�������
                    if (postion.m_stockBalance < readSellCount)
                    {
                        readSellCount = (int)postion.m_stockBalance;
                    }

                    OrderInfo info = new OrderInfo();
                    info.m_code = CStrA.ConvertDBCodeToDealCode(latestData.m_securityCode);
                    info.m_price = (float)Math.Round(latestData.m_close, 2);
                    info.m_qty = readSellCount;
                    m_lastCommissionNoTradePrice = info.m_price;
                    AutoTrade.Sell(info);
                    Thread.Sleep(3000);
                    THSDealInfo req = new THSDealInfo();
                    req.m_operateType = 4;
                    req.m_reqID = DataCenter.ThsDealService.GetRequestID();
                    DataCenter.ThsDealService.AddTHSDealReq(req);
                }
                else if (diffPrice < 0)
                {
                    if (m_securityTradingAccount == null)
                    {
                        // û���ʽ��˻���Ϣ
                        return;
                    }

                    // �����ϴγɽ��۸�
                    int readBuyCount = 0;
                    int sepaCount = (int)(Math.Abs(diffPrice) / overLastDealSell);
                    if (sepaCount < 1)
                    {
                        // �۸�û�дﵽԤ��ֵ
                        return;
                    }
                    if (isCrossBuy)
                    {
                        readBuyCount = sepaCount * buyCount;
                    }
                    else
                    {
                        readBuyCount = buyCount;
                    }

                    if (readBuyCount < 100)
                    {
                        return;
                    }

                    int capitalAllowBuyCount = (int)((m_securityTradingAccount.m_capitalBalance - m_securityTradingAccount.m_frozenCash) / latestData.m_close) / 100 * 100;
                    // �ʽ����С�ڿ��������
                    if (capitalAllowBuyCount < readBuyCount)
                    {
                        readBuyCount = capitalAllowBuyCount;
                    }

                    OrderInfo info = new OrderInfo();
                    info.m_code = CStrA.ConvertDBCodeToDealCode(latestData.m_securityCode);
                    info.m_price = (float)Math.Round(latestData.m_close, 2);
                    info.m_qty = readBuyCount;
                    m_lastCommissionNoTradePrice = info.m_price;
                    AutoTrade.Buy(info);
                    Thread.Sleep(3000);
                    THSDealInfo req = new THSDealInfo();
                    req.m_operateType = 3;
                    req.m_reqID = DataCenter.ThsDealService.GetRequestID();
                    DataCenter.ThsDealService.AddTHSDealReq(req);
                }
            }
            else
            {
            }
        }

        /// <summary>
        /// ������Դ����
        /// </summary>
        public override void Dispose()
        {
            if (!IsDisposed)
            {
                base.Dispose();
            }
        }

        /// <summary>
        /// �˳�����
        /// </summary>
        public override void Exit()
        {
            DataCenter.DisConnect();
        }

        /// <summary>
        /// �Ƿ��д�����ʾ
        /// </summary>
        /// <returns>�Ƿ���ʾ</returns>
        public bool IsWindowShowing()
        {
            List<ControlA> controls = Native.GetControls();
            int controlsSize = controls.Count;
            for (int i = 0; i < controlsSize; i++)
            {
                WindowFrameA frame = controls[i] as WindowFrameA;
                if (frame != null)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// ����XML
        /// </summary>
        /// <param name="xmlPath">XML·��</param>
        public override void Load(String xmlPath)
        {
            LoadFile(xmlPath, null);
            DataCenter.MainUI = this;

            // ί�б���
            m_gridCommissionAccount = GetGrid("gridOrderAccount");
            // �ֱֲ���
            m_gridPositionAccount = GetGrid("gridPositionAccount");
            // �ɽ�����
            m_gridTradeAccount = GetGrid("gridTradeAccount");

            // ��ȡ���佻�ײ���
            m_owChart = new OwChart(this);
            ReloadStrategySetting();

            ControlA control = Native.GetControls()[0];
            control.BackColor = CDraw.PCOLORS_BACKCOLOR9;
            RegisterEvents(control);
            AutoTrade.InitSysTreeView32Handle();

            DataCenter.ThsDealService.RegisterListener(5, ThsDealCallBack);
            DataCenter.ThsDealService.RegisterListener(6, ThsDealCallBack);
            DataCenter.ThsDealService.RegisterListener(7, ThsDealCallBack);
            DataCenter.ThsDealService.RegisterListener(8, ThsDealCallBack);
        }

        /// <summary>
        /// ͬ��˳��Ϣ����
        /// </summary>
        /// <param name="operateType">��������</param>
        /// <param name="requstID">����ID</param>
        /// <param name="result">���صĽ��</param>
        public void ThsDealCallBack(int operateType, int requstID, String resutlt)
        {
            // ��������
            // 0:Ĭ��ֵ
            // 1:����
            // 2:����
            // 3:��������
            // 4:��������
            // 5:��ѯ�ֲ�
            // 6:��ѯ�ɽ�
            // 7:��ѯ�ʽ�
            // 8:��ѯί��
            switch (operateType)
            {
                case 0:
                    break;
                case 1:
                    break;
                case 2:
                    break;
                case 3:
                    break;
                case 4:
                    break;
                case 5:
                    SetSecurityPosition(resutlt);
                    break;
                case 6:
                    SetSecurityTrade(resutlt);
                    break;
                case 7:
                    SetSecurityTradingAccount(resutlt);
                    break;
                case 8:
                    SetSecurityCommission(resutlt);
                    break;
            }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public override void LoadData()
        {
            ButtonA btnStart = GetButton("btnStart");
            if(btnStart == null)
            {
                return;
            }

            if (!m_isStart)
            {
                THSDealInfo req = new THSDealInfo();
                //req.m_operateType = 5;
                //req.m_reqID = DataCenter.ThsDealService.GetRequestID();
                //DataCenter.ThsDealService.AddTHSDealReq(req);
                //req = new THSDealInfo();
                //req.m_operateType = 6;
                //req.m_reqID = DataCenter.ThsDealService.GetRequestID();
                //DataCenter.ThsDealService.AddTHSDealReq(req);
                //req = new THSDealInfo();
                req.m_operateType = 7;
                req.m_reqID = DataCenter.ThsDealService.GetRequestID();
                DataCenter.ThsDealService.AddTHSDealReq(req);
                //req = new THSDealInfo();
                //req.m_operateType = 8;
                //req.m_reqID = DataCenter.ThsDealService.GetRequestID();
                //DataCenter.ThsDealService.AddTHSDealReq(req);
                DataCenter.ThsDealService.StartTHSDealService();
                m_isStart = true;
                btnStart.Text = "ֹͣ";
            }
            else
            {
                m_isStart = false;
                btnStart.Text = "����";
            }
        }

        /// ע���¼�
        /// </summary>
        /// <param name="control">�ؼ�</param>
        private void RegisterEvents(ControlA control)
        {
            ControlMouseEvent clickButtonEvent = new ControlMouseEvent(ClickEvent);
            List<ControlA> controls = control.GetControls();
            int controlsSize = controls.Count;
            for (int i = 0; i < controlsSize; i++)
            {
                ControlA subControl = controls[i];
                ButtonA button = subControl as ButtonA;
                GridColumn column = subControl as GridColumn;
                GridA grid = subControl as GridA;
                CheckBoxA checkBox = subControl as CheckBoxA;
                if (column != null)
                {
                    column.AllowResize = true;
                    column.BackColor = CDraw.PCOLORS_BACKCOLOR;
                    column.BorderColor = CDraw.PCOLORS_LINECOLOR2;
                    column.ForeColor = CDraw.PCOLORS_FORECOLOR;
                }
                else if (checkBox != null)
                {
                    checkBox.ButtonBackColor = CDraw.PCOLORS_BACKCOLOR;
                }
                else if (button != null)
                {
                    button.RegisterEvent(clickButtonEvent, EVENTID.CLICK);
                }
                else if (grid != null)
                {
                    grid.BackColor = COLOR.EMPTY;
                    grid.GridLineColor = CDraw.PCOLORS_LINECOLOR2;
                    GridRowStyle rowStyle = new GridRowStyle();
                    grid.RowStyle = rowStyle;
                    rowStyle.BackColor = COLOR.EMPTY;
                    rowStyle.SelectedBackColor = CDraw.PCOLORS_SELECTEDROWCOLOR;
                    rowStyle.HoveredBackColor = CDraw.PCOLORS_HOVEREDROWCOLOR;
                    grid.HorizontalOffset = grid.Width;
                    grid.UseAnimation = true;
                }
                else
                {
                    if (subControl.GetControlType() == "Div" || subControl.GetControlType() == "TabControl"
                        || subControl.GetControlType() == "TabPage"
                        || subControl.GetControlType() == "SplitLayoutDiv")
                    {
                        subControl.BackColor = COLOR.EMPTY;
                    }
                }
                RegisterEvents(controls[i]);
            }
        }

        /// <summary>
        /// ���¼��ؽ��ײ���
        /// </summary>
        public void ReloadStrategySetting()
        {
            // ��ȡ���佻�ײ���
            DataCenter.StrategySettingService.GetSecurityStrategySettings(0, m_securityStrategySettings);
            Security security = null;
            if (m_securityStrategySettings != null && m_securityStrategySettings.Count > 0)
            {
                m_securityStrategySettingCurrnet = m_securityStrategySettings[0];
                security = new Security();
                security.m_code = m_securityStrategySettingCurrnet.m_securityCode;
                security.m_name = m_securityStrategySettingCurrnet.m_securityName;
            }
            
            m_owChart.SearchSecurity = security;
        }

        /// <summary>
        /// ���ù�Ʊ�˻�ί����Ϣ
        /// </summary>
        /// <param name="commissionResult"></param>
        private void SetSecurityCommission(String commissionResult)
        {
            if (commissionResult == null || commissionResult.Length == 0)
            {
                return;
            }
            String[] lines = commissionResult.Split(Environment.NewLine.ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            if (lines == null || lines.Length < 2)
            {
                return;
            }

            m_gridCommissionAccount.BeginUpdate();
            m_gridCommissionAccount.ClearRows();
            for (int i = 1; i < lines.Length; i++)
            {
                SecurityCommission commission = SecurityCommission.ConvertToSecurityCommission(lines[i]);
                if (commission != null)
                {
                    GridRow row = new GridRow();
                    m_gridCommissionAccount.AddRow(row);
                    GridCell cell = new GridStringCell(commission.m_orderDate);
                    row.AddCell(0, cell);
                    cell = new GridStringCell(commission.m_stockCode);
                    row.AddCell(1, cell);
                    cell = new GridStringCell(commission.m_stockName);
                    row.AddCell(2, cell);
                    cell = new GridStringCell(commission.m_operate);
                    row.AddCell(3, cell);
                    cell = new GridStringCell(commission.m_remark);
                    row.AddCell(4, cell);
                    cell = new GridDoubleCell(commission.m_orderVolume);
                    row.AddCell(5, cell);
                    cell = new GridDoubleCell(commission.m_tradeVolume);
                    row.AddCell(6, cell);
                    cell = new GridDoubleCell(commission.m_cancelVolume);
                    row.AddCell(7, cell);
                    cell = new GridDoubleCell(commission.m_orderPrice);
                    row.AddCell(8, cell);
                    cell = new GridStringCell(commission.m_orderType);
                    row.AddCell(9, cell);
                    cell = new GridDoubleCell(commission.m_tradeAvgPrice);
                    row.AddCell(10, cell);
                    cell = new GridStringCell(commission.m_orderSysID);
                    row.AddCell(11, cell);
                }
            }
            m_gridCommissionAccount.EndUpdate();
            m_gridCommissionAccount.Invalidate();
        }

        /// <summary>
        /// ���ù�Ʊ�˻��ֲ���Ϣ
        /// </summary>
        /// <param name="stockPositionResult"></param>
        private void SetSecurityPosition(String stockPositionResult)
        {
            m_dictSecurityPositions.Clear();
            if (stockPositionResult == null || stockPositionResult.Length == 0)
            {
                return;
            }
            String[] lines = stockPositionResult.Split(Environment.NewLine.ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            if(lines == null || lines.Length < 2)
            {
                return;
            }

            m_gridPositionAccount.BeginUpdate();
            m_gridPositionAccount.ClearRows();
            for (int i = 1; i < lines.Length; i++)
            {
                SecurityPosition position = SecurityPosition.ConvertToStockPosition(lines[i]);
                if(position != null)
                {
                    m_dictSecurityPositions[position.m_stockCode] = position;

                    GridRow row = new GridRow();
                    m_gridPositionAccount.AddRow(row);
                    GridCell cell = new GridStringCell(position.m_stockCode);
                    row.AddCell(0, cell);
                    cell = new GridStringCell(position.m_stockName);
                    row.AddCell(1, cell);
                    cell = new GridDoubleCell(position.m_stockBalance);
                    row.AddCell(2, cell);
                    cell = new GridDoubleCell(position.m_availableBalance);
                    row.AddCell(3, cell);
                    cell = new GridDoubleCell(position.m_volume);
                    row.AddCell(4, cell);
                    cell = new GridDoubleCell(position.m_frozenVolume);
                    row.AddCell(5, cell);
                    cell = new GridDoubleCell(position.m_positionProfit);
                    row.AddCell(6, cell);
                    cell = new GridDoubleCell(position.m_positionCost);
                    row.AddCell(7, cell);
                    cell = new GridDoubleCell(position.m_positionProfitRatio);
                    row.AddCell(8, cell);
                    cell = new GridDoubleCell(position.m_marketPrice);
                    row.AddCell(9, cell);
                    cell = new GridDoubleCell(position.m_marketValue);
                    row.AddCell(10, cell);
                    cell = new GridDoubleCell(position.m_redemptionVolume);
                    row.AddCell(11, cell);
                    cell = new GridStringCell(position.m_marketName);
                    row.AddCell(12, cell);
                    cell = new GridStringCell(position.m_investorAccount);
                    row.AddCell(13, cell);
                }
            }
            m_gridPositionAccount.EndUpdate();
            m_gridPositionAccount.Invalidate();
        }

        /// <summary>
        /// ���ù�Ʊ�˻��ɽ���Ϣ
        /// </summary>
        /// <param name="tradeResult"></param>
        private void SetSecurityTrade(String tradeResult)
        {
            if (tradeResult == null || tradeResult.Length == 0)
            {
                return;
            }
            String[] lines = tradeResult.Split(Environment.NewLine.ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            if (lines == null || lines.Length < 2)
            {
                return;
            }

            m_gridTradeAccount.BeginUpdate();
            m_gridTradeAccount.ClearRows();
            for (int i = 1; i < lines.Length; i++)
            {
                SecurityTrade trade = SecurityTrade.ConvertToStockTrade(lines[i]);
                if (trade != null)
                {
                    GridRow row = new GridRow();
                    m_gridTradeAccount.AddRow(row);
                    GridCell cell = new GridStringCell(trade.m_tradeDate);
                    row.AddCell(0, cell);
                    cell = new GridStringCell(trade.m_stockCode);
                    row.AddCell(1, cell);
                    cell = new GridStringCell(trade.m_stockName);
                    row.AddCell(2, cell);
                    cell = new GridStringCell(trade.m_operate);
                    row.AddCell(3, cell);
                    cell = new GridDoubleCell(trade.m_tradeVolume);
                    row.AddCell(4, cell);
                    cell = new GridDoubleCell(trade.m_tradeAvgPrice);
                    row.AddCell(5, cell);
                    cell = new GridDoubleCell(trade.m_tradeAmount);
                    row.AddCell(6, cell);
                    cell = new GridStringCell(trade.m_orderSysID);
                    row.AddCell(7, cell);
                    cell = new GridStringCell(trade.m_orderTradeID);
                    row.AddCell(8, cell);
                    cell = new GridDoubleCell(trade.m_cancelVolume);
                    row.AddCell(9, cell);
                    cell = new GridDoubleCell(trade.m_stockBalance);
                    row.AddCell(10, cell);
                }
            }
            m_gridTradeAccount.EndUpdate();
            m_gridTradeAccount.Invalidate();
        }

        /// <summary>
        /// ���ù�Ʊ�˻��ʽ�
        /// </summary>
        /// <param name="tradeResult"></param>
        private void SetSecurityTradingAccount(String stockCaptialResult)
        {
            m_securityTradingAccount = null;
            if (stockCaptialResult == null || stockCaptialResult.Length == 0)
            {
                return;
            }
            SecurityTradingAccount stockTradingAccount = SecurityTradingAccount.ConvertToStockTradingAccount(stockCaptialResult);
            if (stockTradingAccount == null)
            {
                return;
            }
            m_securityTradingAccount = stockTradingAccount;
            LabelA lblCapitalBalance = GetLabel("lblCapitalBalance");
            if (lblCapitalBalance != null)
            {
                lblCapitalBalance.Text = stockTradingAccount.m_capitalBalance.ToString();
            }
            LabelA lblFrozenCash = GetLabel("lblFrozenCash");
            if (lblFrozenCash != null)
            {
                lblFrozenCash.Text = stockTradingAccount.m_frozenCash.ToString();
            }
            LabelA lblAvailable = GetLabel("lblAvailable");
            if (lblAvailable != null)
            {
                lblAvailable.Text = stockTradingAccount.m_available.ToString();
            }
            LabelA lblWithdrawQuota = GetLabel("lblWithdrawQuota");
            if (lblWithdrawQuota != null)
            {
                lblWithdrawQuota.Text = stockTradingAccount.m_withdrawQuota.ToString();
            }
            LabelA lblStockValue = GetLabel("lblStockValue");
            if (lblStockValue != null)
            {
                lblStockValue.Text = stockTradingAccount.m_stockValue.ToString();
            }
            LabelA lblTotalCapital = GetLabel("lblTotalCapital");
            if (lblTotalCapital != null)
            {
                lblTotalCapital.Text = stockTradingAccount.m_totalCapital.ToString();
            }

            DivA divCapital = GetDiv("divCapital");
            divCapital.Invalidate();
        }

        /// <summary>
        /// ��ʾ��¼����
        /// </summary>
        public void ShowLoginWindow()
        {
            LoginWindow loginWindow = new LoginWindow(Native);
            loginWindow.MainFrame = this;
            loginWindow.Show();
        }

        /// <summary>
        /// ��ʾ��ʾ����
        /// </summary>
        /// <param name="text">�ı�</param>
        /// <param name="caption">����</param>
        /// <param name="uType">��ʽ</param>
        /// <returns>���</returns>
        public int ShowMessageBox(String text, String caption, int uType)
        {
            MessageBox.Show(text, caption);
            return 1;
        }

        /// <summary>
        /// ��ʾ���ò��Դ���
        /// </summary>
        public void ShowStrategySettingWindow()
        {
            SecurityStrategySetting securityStrategySetting = null;
            if (m_securityStrategySettings.Count > 0)
            {
                securityStrategySetting = m_securityStrategySettings[0];
            }
            SecurityRangeTradeConditionWindow strategySettingWindow  = new SecurityRangeTradeConditionWindow(Native);
            strategySettingWindow.MainFrame = this;
            strategySettingWindow.SecurityStrategySetting = securityStrategySetting;
            strategySettingWindow.Show();

        }
    }
}
