﻿using System;
using System.Collections.Generic;

namespace LordStockAT
{
    /// <summary>
    ///  证券服务
    /// </summary>
    public class SecurityService : BaseService
    {
        #region Lord 2016/12/29
        /// <summary>
        /// 创建条件选股服务
        /// </summary>
        public SecurityService()
        {
            ServiceID = SERVICEID_SECURITY;
        }

        /// <summary>
        /// 证券服务ID
        /// </summary>
        public const int SERVICEID_SECURITY = 3;

        /// <summary>
        /// 获取证券信息方法ID
        /// </summary>
        public const int FUNCTIONID_SECURITY_GETSECURITIES = 0;

        /// <summary>
        /// 根据ID获取证券信息方法ID
        /// </summary>
        public const int FUNCTIONID_SECURITY_GETSECURITIESBYID = 1;

        private int m_socketID = 0;

        /// <summary>
        /// 获取或设置套接字ID
        /// </summary>
        public int SocketID
        {
            get { return m_socketID; }
            set { m_socketID = value; }
        }

        /// <summary>
        /// 获取所有证券
        /// </summary>
        /// <param name="requestID">请求ID</param>
        /// <returns>状态</returns>
        public int GetSecurities(int requestID)
        {
            Binary bw = new Binary();
            bw.WriteString("lord");
            byte[] bytes = bw.GetBytes();
            int ret = Send(new CMessage(GroupID, ServiceID, FUNCTIONID_SECURITY_GETSECURITIES, SessionID, requestID, m_socketID, 0, CompressType, bytes.Length, bytes));
            bw.Close();
            return ret > 0 ? 1 : 0;
        }

        /// <summary>
        /// 根据板块ID获取证券信息
        /// </summary>
        /// <param name="requestID">请求ID</param>
        /// <param name="blockID">板块ID</param>
        /// <returns>状态</returns>
        public int GetSecuritiesByBlockID(int requestID, String blockID)
        {
            Binary bw = new Binary();
            bw.WriteString(blockID);
            byte[] bytes = bw.GetBytes();
            int ret = Send(new CMessage(GroupID, ServiceID, FUNCTIONID_SECURITY_GETSECURITIESBYID, SessionID, requestID, m_socketID, 0, CompressType, bytes.Length, bytes));
            bw.Close();
            return ret > 0 ? 1 : 0;
        }

        /// <summary>
        /// 通过流获取证券信息
        /// </summary>
        /// <param name="securities">证券信息</param>
        /// <param name="functionID">方法ID</param>
        /// <param name="body">包体</param>
        /// <param name="bodyLength">包体长度</param>
        /// <returns>状态</returns>
        public static int GetSecurities(List<Security> securities, int functionID, byte[] body, int bodyLength)
        {
            Binary br = new Binary();
            br.Write(body, bodyLength);
            int size = br.ReadInt();
            if (size > 0)
            {
                for (int i = 0; i < size; i++)
                {
                    Security security = new Security();
                    security.m_code = br.ReadString();
                    if (functionID == FUNCTIONID_SECURITY_GETSECURITIES)
                    {
                        security.m_name = br.ReadString();
                        security.m_pingyin = br.ReadString();
                        security.m_type = br.ReadShort();
                        security.m_status = (int)br.ReadChar();
                    }
                    securities.Add(security);
                }
            }
            br.Close();
            return 1;
        }

        /// <summary>
        /// 接收数据
        /// </summary>
        /// <param name="message">消息</param>
        public override void OnReceive(CMessage message)
        {
            base.OnReceive(message);
            SendToListener(message);
        }
        #endregion
    }
}
