/*******************************************************************************************\
*                                                                                           *
* HttpPostService.cs -  Http post service functions, types, and definitions.                *
*                                                                                           *
*               Version 1.00  ����                                                        *
*                                                                                           *
*               Copyright (c) 2016-2016, Piratecat. All rights reserved.                    *
*               Created by Lord 2016/10/17.                                                  *
*                                                                                           *
********************************************************************************************/

using System;
using System.Collections.Generic;
using System.Net;
using System.IO.Compression;
using OwLib;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;

namespace LordStockAT
{
    /// <summary>
    /// HTTP��POST����
    /// </summary>
    public class HttpPostService : BaseService
    {
        /// <summary>
        /// ����HTTP����
        /// </summary>
        public HttpPostService()
        {
            CompressType = COMPRESSTYPE_NONE;
            ServiceID = SERVICEID_HTTPPOST;
        }

        /// <summary>
        /// �û��Ự����ID
        /// </summary>
        public const int SERVICEID_HTTPPOST = 20;

        /// <summary>
        /// POST����ID
        /// </summary>
        public const int FUNCTIONID_HTTPPOST_TEST = 0;

        private string m_url;

        /// <summary>
        /// ��ȡ�����õ�ַ
        /// </summary>
        public string Url
        {
            get { return m_url; }
            set { m_url = value; }
        }

        /// <summary>
        /// �첽��������
        /// </summary>
        /// <param name="obj"></param>
        public void AsynSend(Object obj)
        {
            CMessage message = obj as CMessage;
            if (message == null)
            {
                return;
            }

            Binary bw = new Binary();
            byte[] body = message.m_body;
            int bodyLength = message.m_bodyLength;
            int uncBodyLength = bodyLength;
            if (message.m_compressType == COMPRESSTYPE_GZIP)
            {
                using (MemoryStream cms = new MemoryStream())
                {
                    using (GZipStream gzip = new GZipStream(cms, CompressionMode.Compress))
                    {
                        gzip.Write(body, 0, body.Length);
                    }
                    body = cms.ToArray();
                    bodyLength = body.Length;
                }
            }
            int len = sizeof(int) * 4 + bodyLength + sizeof(short) * 3 + sizeof(byte) * 2;
            bw.WriteInt(len);
            bw.WriteShort((short)message.m_groupID);
            bw.WriteShort((short)message.m_serviceID);
            bw.WriteShort((short)message.m_functionID);
            bw.WriteInt(message.m_sessionID);
            bw.WriteInt(message.m_requestID);
            bw.WriteByte((byte)message.m_state);
            bw.WriteByte((byte)message.m_compressType);
            bw.WriteInt(uncBodyLength);
            bw.WriteBytes(body);
            byte[] bytes = bw.GetBytes();
            int length = bytes.Length;
            HttpWebRequest webReq = (HttpWebRequest)WebRequest.Create(m_url);
            webReq.Method = "POST";
            webReq.ContentType = "application/x-www-form-urlencoded";
            webReq.ContentLength = bytes.Length;
            Stream writer = webReq.GetRequestStream();
            writer.Write(bytes, 0, bytes.Length);
            writer.Close();
            HttpWebResponse response = (HttpWebResponse)webReq.GetResponse();
            Stream reader = response.GetResponseStream();
            long contentLength = response.ContentLength;
            byte[] dataArray = new byte[contentLength];
            reader.Read(dataArray, 0, (int)contentLength);
            response.Close();
            reader.Dispose();
            bw.Close();
            int ret = dataArray.Length;
            UpFlow += ret;
            IntPtr ptr = Marshal.AllocHGlobal(sizeof(byte) * ret);
            for (int i = 0; i < ret; i++)
            {
                IntPtr iptr = (IntPtr)((int)ptr + i);
                Marshal.WriteByte(iptr, dataArray[i]);
            }
            BaseService.CallBack(message.m_socketID, 0, ptr, ret);
            Marshal.FreeHGlobal(ptr);
        }

        /// <summary>
        /// ��ȡ��������
        /// </summary>
        /// <param name="grid">����</param>
        /// <returns>��</returns>
        public static byte[] GetBytes(GridA grid)
        {
            Binary br = new Binary();
            br.WriteString(grid.Name);
            List<GridColumn> columns = grid.GetColumns();
            int columnsSize = columns.Count;
            br.WriteInt(columnsSize);
            for (int i = 0; i < columnsSize; i++)
            {
                GridColumn column = columns[i];
                br.WriteString(column.Name);
                br.WriteString(column.ColumnType);
            }
            List<GridRow> rows = grid.GetRows();
            int rowsCount = rows.Count;
            br.WriteInt(rowsCount);
            for (int i = 0; i < rowsCount; i++)
            {
                GridRow row = rows[i];
                for (int j = 0; j < columnsSize; j++)
                {
                    GridColumn column = columns[j];
                    String columnType = column.ColumnType.ToLower();
                    GridCell cell = row.GetCell(j);
                    if (columnType == "bool")
                    {
                        br.WriteBool(cell.GetBool());
                    }
                    else if (columnType == "double")
                    {
                        br.WriteDouble(cell.GetDouble());
                    }
                    else if (columnType == "float")
                    {
                        br.WriteFloat(cell.GetFloat());
                    }
                    else if (columnType == "int")
                    {
                        br.WriteInt(cell.GetInt());
                    }
                    else if (columnType == "long")
                    {
                        br.WriteDouble(cell.GetLong());
                    }
                    else if (columnType == "string")
                    {
                        br.WriteString(cell.GetString());
                    }
                }
            }
            byte[] bytes = br.GetBytes();
            return bytes;
        }

        /// <summary>
        /// ��ȡ����
        /// </summary>
        /// <param name="bytes">��</param>
        /// <param name="native">������</param>
        /// <returns>����</returns>
        public static GridA GetGrid(byte[] bytes, INativeBase native)
        {
            Binary br = new Binary();
            br.Write(bytes, bytes.Length);
            GridA grid = new GridA();
            grid.Native = native;
            grid.Name = br.ReadString();
            int columnsSize = br.ReadInt();
            for (int i = 0; i < columnsSize; i++)
            {
                GridColumn column = new GridColumn();
                column.Name = br.ReadString();
                column.ColumnType = br.ReadString();
                grid.AddColumn(column);
            }
            grid.Update();
            List<GridColumn> columns = grid.GetColumns();
            int rowsCount = br.ReadInt();
            for (int i = 0; i < rowsCount; i++)
            {
                GridRow row = new GridRow();
                grid.AddRow(row);
                for (int j = 0; j < columnsSize; j++)
                {
                    GridColumn column = columns[j];
                    string columnType = column.ColumnType.ToLower();
                    GridCell cell = null;
                    if (columnType == "bool")
                    {
                        cell = new GridBoolCell();
                        row.AddCell(j, cell);
                        cell.SetBool(br.ReadBool());
                    }
                    else if (columnType == "double")
                    {
                        cell = new GridDoubleCell();
                        row.AddCell(j, cell);
                        cell.SetDouble(br.ReadDouble());
                    }
                    else if (columnType == "float")
                    {
                        cell = new GridFloatCell();
                        row.AddCell(j, cell);
                        cell.SetFloat(br.ReadFloat());
                    }
                    else if (columnType == "int")
                    {
                        cell = new GridIntCell();
                        row.AddCell(j, cell);
                        cell.SetInt(br.ReadInt());
                    }
                    else if (columnType == "long")
                    {
                        cell = new GridLongCell();
                        row.AddCell(j, cell);
                        cell.SetLong((long)br.ReadDouble());
                    }
                    else if (columnType == "string")
                    {
                        cell = new GridStringCell();
                        row.AddCell(j, cell);
                        cell.SetString(br.ReadString());
                    }
                    else
                    {
                        cell = new GridStringCell();
                        row.AddCell(j, cell);
                        cell.SetString(br.ReadString());
                    }
                }
            }
            return grid;
        }

        /// <summary>
        /// ��������
        /// </summary>
        /// <param name="message">��Ϣ</param>
        public override void OnReceive(CMessage message)
        {
            base.OnReceive(message);
            SendToListener(message);
        }

        /// <summary>
        /// ����POST����
        /// </summary>
        /// <param name="message">��Ϣ</param>
        /// <returns>������Ϣ</returns>
        public override int Send(CMessage message)
        {
            Thread thread = new Thread(AsynSend);
            thread.Start(message);    
            return 1;
        }

        /// <summary>
        /// ���Է���
        /// </summary>
        /// <param name="requestID">����ID</param>
        /// <param name="bytes">��Ϣ</param>
        /// <returns>������Ϣ</returns>
        public int Test(int requestID, byte[] bytes)
        {
            int ret = Send(new CMessage(GroupID, ServiceID, FUNCTIONID_HTTPPOST_TEST, SessionID, requestID, 0, 0, CompressType, bytes.Length, bytes));
            return ret > 0 ? 1 : 0;
        }
    }
}
