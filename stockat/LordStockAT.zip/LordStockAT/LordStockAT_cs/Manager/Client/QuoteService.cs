﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LordStockAT
{
    /// <summary>
    /// 行情服务
    /// </summary>
    public class QuoteService : BaseService
    {
        #region Lord 2016/7/5
        /// <summary>
        /// 创建服务
        /// </summary>
        public QuoteService()
        {
            ServiceID = SERVICEID_QUOTE;
        }

        /// <summary>
        /// 析构函数
        /// </summary>
        ~QuoteService()
        {
        }

        private int m_socketID = -1;

        /// <summary>
        /// 获取或设置套接字ID
        /// </summary>
        public int SocketID
        {
            get { return m_socketID; }
            set { m_socketID = value; }
        }

        /// <summary>
        /// 推送最新数据的功能ID
        /// </summary>
        public const int FUNCTIONID_QUOTE_PUSHLATESTDATA = 0;

        /// <summary>
        /// 推送历史数据日线的功能ID
        /// </summary>
        public const int FUNCTIONID_QUOTE_PUSHHISTORYDATA = 1;

        /// <summary>
        /// 停止推送历史数据的功能ID
        /// </summary>
        public const int FUNCTIONID_QUOTE_STOPPUSHHISTORYDATA = 3;

        /// <summary>
        /// 停止推送最新数据的功能ID
        /// </summary>
        public const int FUNCTIONID_QUOTE_STOPPUSHLATESTDATA = 4;

        /// <summary>
        /// 获取最新数据的功能ID
        /// </summary>
        public const int FUNCTIONID_QUOTE_GETLATESTDATA = 5;

        /// <summary>
        /// 获取历史数据的功能ID
        /// </summary>
        public const int FUNCTIONID_QUOTE_GETHISTORYDATA = 6;

        /// <summary>
        /// 推送成交数据的功能ID
        /// </summary>
        public const int FUNCTIONID_QUOTE_PUSHTRANSACTIONDATA = 7;

        /// <summary>
        /// 获取成交量预测的功能ID
        /// </summary>
        public const int FUNCTIONID_QUOTE_GETVOLUMEFORECAST = 8;

        /// <summary>
        /// 推送最新数据LV2
        /// </summary>
        public const int FUNCTIONID_QUOTE_PUSHLATESTDATALV2 = 9;

        /// <summary>
        /// 行情服务ID
        /// </summary>
        public const int SERVICEID_QUOTE = 0;

        /// <summary>
        /// 获取历史数据
        /// </summary>
        /// <param name="dataInfo">数据信息</param>
        /// <param name="datas">历史数据列表</param>
        /// <param name="body">数据</param>
        /// <param name="bodyLength">包体长度</param>
        /// <returns>状态</returns>
        public static int GetHistoryDatas(ref HistoryDataInfo dataInfo, List<SecurityData> datas, byte[] body, int bodyLength)
        {
            Binary br = new Binary();
            br.Write(body, bodyLength);
            dataInfo.m_securityCode = br.ReadString();
            dataInfo.m_type = (int)br.ReadChar();
            dataInfo.m_size = br.ReadInt();
            dataInfo.m_cycle = br.ReadInt();
            dataInfo.m_subscription = br.ReadInt();
            dataInfo.m_startDate = br.ReadDouble();
            dataInfo.m_endDate = br.ReadDouble();
            dataInfo.m_pushData = br.ReadBool();
            int count = dataInfo.m_size;
            for (int i = 0; i < count; i++)
            {
                SecurityData data = new SecurityData();
                data.m_date = br.ReadDouble();
                data.m_close = br.ReadFloat();
                data.m_high = br.ReadFloat();
                data.m_low = br.ReadFloat();
                data.m_open = br.ReadFloat();
                data.m_volume = br.ReadDouble();
                data.m_amount = br.ReadDouble();
                if (dataInfo.m_cycle == 0)
                {
                    data.m_avgPrice = br.ReadFloat();
                }
                datas.Add(data);
            }
            br.Close();
            return 1;
        }

        /// <summary>
        /// 请求历史数据
        /// </summary>
        /// <param name="requestID">请求ID</param>
        /// <param name="dataInfo">数据信息</param>
        /// <param name="functionID">功能ID</param>
        /// <returns>状态</returns>
        public int GetHistoryDatas(int requestID, HistoryDataInfo dataInfo)
        {
            return Send(FUNCTIONID_QUOTE_GETHISTORYDATA, requestID, m_socketID, dataInfo) > 0 ? 1 : 0;
        }

        /// <summary>
        /// 获取最新数据
        /// </summary>
        /// <param name="dataInfo">数据信息</param>
        /// <param name="datas">最新数据列表</param>
        /// <param name="body">数据</param>
        /// <param name="bodyLength">包体长度</param>
        /// <returns>状态</returns>
        public static int GetLatestDatas(ref LatestDataInfo dataInfo, List<SecurityLatestData> datas, byte[] body, int bodyLength)
        {
            Binary br = new Binary();
            br.Write(body, bodyLength);
            dataInfo.m_formatType = (int)br.ReadChar();
            dataInfo.m_lv2 = (int)br.ReadChar();
            dataInfo.m_size = br.ReadInt();
            for (int i = 0; i < dataInfo.m_size; i++)
            {
                SecurityLatestData latestData = new SecurityLatestData();
                latestData.m_securityCode = br.ReadString();
                latestData.m_open = br.ReadFloat();
                latestData.m_lastClose = br.ReadFloat();
                latestData.m_close = br.ReadFloat();
                latestData.m_high = br.ReadFloat();
                latestData.m_low = br.ReadFloat();
                latestData.m_volume = br.ReadDouble();
                latestData.m_amount = br.ReadDouble();
                if (dataInfo.m_formatType == 0)
                {
                    latestData.m_buyVolume1 = br.ReadInt();
                    latestData.m_buyPrice1 = br.ReadFloat();
                    latestData.m_buyVolume2 = br.ReadInt();
                    latestData.m_buyPrice2 = br.ReadFloat();
                    latestData.m_buyVolume3 = br.ReadInt();
                    latestData.m_buyPrice3 = br.ReadFloat();
                    latestData.m_buyVolume4 = br.ReadInt();
                    latestData.m_buyPrice4 = br.ReadFloat();
                    latestData.m_buyVolume5 = br.ReadInt();
                    latestData.m_buyPrice5 = br.ReadFloat();
                    latestData.m_sellVolume1 = br.ReadInt();
                    latestData.m_sellPrice1 = br.ReadFloat();
                    latestData.m_sellVolume2 = br.ReadInt();
                    latestData.m_sellPrice2 = br.ReadFloat();
                    latestData.m_sellVolume3 = br.ReadInt();
                    latestData.m_sellPrice3 = br.ReadFloat();
                    latestData.m_sellVolume4 = br.ReadInt();
                    latestData.m_sellPrice4 = br.ReadFloat();
                    latestData.m_sellVolume5 = br.ReadInt();
                    latestData.m_sellPrice5 = br.ReadFloat();
                    latestData.m_innerVol = br.ReadInt();
                    latestData.m_outerVol = br.ReadInt();
                    latestData.m_turnoverRate = br.ReadFloat();
                    latestData.m_openInterest = br.ReadDouble();
                    latestData.m_settlePrice = br.ReadFloat();
                }
                latestData.m_date = br.ReadDouble();
                datas.Add(latestData);
            }
            br.Close();
            return 1;
        }

        /// <summary>
        /// 获取LV2最新数据
        /// </summary>
        /// <param name="dataInfo">数据信息</param>
        /// <param name="datas">最新数据列表</param>
        /// <param name="body">数据</param>
        /// <param name="bodyLength">包体长度</param>
        /// <returns>状态</returns>
        public static int GetLatestDatasLV2(ref LatestDataInfoLV2 dataInfo, List<SecurityLatestDataLV2> datas, byte[] body, int bodyLength)
        {
            Binary br = new Binary();
            br.Write(body, bodyLength);
            dataInfo.m_size = br.ReadInt();
            for (int i = 0; i < dataInfo.m_size; i++)
            {
                SecurityLatestDataLV2 latestData = new SecurityLatestDataLV2();
                latestData.m_securityCode = br.ReadString();
                latestData.m_allBuyVol = br.ReadDouble();
                latestData.m_avgBuyPrice = br.ReadFloat();
                latestData.m_allSellVol = br.ReadDouble();
                latestData.m_avgSellPrice = br.ReadFloat();
                latestData.m_buyVolume6 = br.ReadInt();
                latestData.m_buyPrice6 = br.ReadFloat();
                latestData.m_buyVolume7 = br.ReadInt();
                latestData.m_buyPrice7 = br.ReadFloat();
                latestData.m_buyVolume8 = br.ReadInt();
                latestData.m_buyPrice8 = br.ReadFloat();
                latestData.m_buyVolume9 = br.ReadInt();
                latestData.m_buyPrice9 = br.ReadFloat();
                latestData.m_buyVolume10 = br.ReadInt();
                latestData.m_buyPrice10 = br.ReadFloat();
                latestData.m_sellVolume6 = br.ReadInt();
                latestData.m_sellPrice6 = br.ReadFloat();
                latestData.m_sellVolume7 = br.ReadInt();
                latestData.m_sellPrice7 = br.ReadFloat();
                latestData.m_sellVolume8 = br.ReadInt();
                latestData.m_sellPrice8 = br.ReadFloat();
                latestData.m_sellVolume9 = br.ReadInt();
                latestData.m_sellPrice9 = br.ReadFloat();
                latestData.m_sellVolume10 = br.ReadInt();
                latestData.m_sellPrice10 = br.ReadFloat();
                datas.Add(latestData);
            }
            br.Close();
            return 1;
        }

        /// <summary>
        /// 请求最新数据
        /// </summary>
        /// <param name="requestID">请求ID</param>
        /// <param name="dataInfo">请求信息</param>
        /// <returns>状态</returns>
        public int GetLatestDatas(int requestID, LatestDataInfo dataInfo)
        {
            return Send(FUNCTIONID_QUOTE_GETLATESTDATA, requestID, m_socketID, dataInfo) > 0 ? 1 : 0;
        }

        /// <summary>
        /// 获取成交数据
        /// </summary>
        /// <param name="securityCode">股票代码</param>
        /// <param name="transactionDatas">成交数据</param>
        /// <param name="body">包体</param>
        /// <param name="bodyLength">包体长度</param>
        /// <returns>状态</returns>
        public static int GetTransactionDatas(ref String securityCode, List<TransactionData> transactionDatas, byte[] body, int bodyLength)
        {
            Binary br = new Binary();
            br.Write(body, bodyLength);
            securityCode = br.ReadString();
            int dataSize = br.ReadInt();
            for (int i = 0; i < dataSize; i++)
            {
                TransactionData data = new TransactionData();
                data.m_date = br.ReadDouble();
                data.m_price = br.ReadFloat();
                data.m_volume = br.ReadDouble();
                data.m_type = (int)br.ReadChar();
                transactionDatas.Add(data);
            }
            br.Close();
            return 1;
        }

        /// <summary>
        /// 获取成交量预测值
        /// </summary>
        /// <param name="requestID">请求ID</param>
        /// <param name="securityCode">股票代码</param>
        /// <returns>状态</returns>
        public int GetVolumeForecast(int requestID, String securityCode)
        {
            Binary bw = new Binary();
            bw.WriteInt(1);
            bw.WriteString(securityCode);
            bw.WriteDouble((double)0);
            byte[] bytes = bw.GetBytes();
            bw.Close();
            return Send(new CMessage(GroupID, ServiceID, FUNCTIONID_QUOTE_GETVOLUMEFORECAST, SessionID, requestID, m_socketID, 0, CompressType, bytes.Length, bytes)) > 0 ? 1 : 0;
        }
        
        /// <summary>
        /// 接收数据
        /// </summary>
        /// <param name="message">消息</param>
        public override void OnReceive(CMessage message)
        {
            base.OnReceive(message);
            SendToListener(message);
        }

        /// <summary>
        /// 推送历史数据
        /// </summary>
        /// <param name="requestID">请求ID</param>
        /// <param name="dataInfo">数据信息</param>
        /// <param name="functionID">功能ID</param>
        /// <returns>状态</returns>
        public int PushHistoryDatas(int requestID, HistoryDataInfo dataInfo)
        {
            return Send(FUNCTIONID_QUOTE_PUSHHISTORYDATA, requestID, m_socketID, dataInfo) > 0 ? 1 : 0;
        }

        /// <summary>
        /// 推送最新数据
        /// </summary>
        /// <param name="requestID">请求ID</param>
        /// <param name="dataInfo">请求信息</param>
        /// <returns>状态</returns>
        public int PushLatestDatas(int requestID, LatestDataInfo dataInfo)
        {
            return Send(FUNCTIONID_QUOTE_PUSHLATESTDATA, requestID, m_socketID, dataInfo) > 0 ? 1 : 0;
        }

        /// <summary>
        /// 停止推送历史数据
        /// </summary>
        /// <param name="requestID">请求ID</param>
        /// <returns>状态</returns>
        public int StopPushHistoryDatas(int requestID)
        {
            byte[] bytes = Encoding.UTF8.GetBytes("1");
            return Send(new CMessage(GroupID, ServiceID, FUNCTIONID_QUOTE_STOPPUSHHISTORYDATA, SessionID, requestID, m_socketID, 0, CompressType, bytes.Length, bytes)) > 0 ? 1 : 0;
        }

        /// <summary>
        /// 停止推送最新数据
        /// </summary>
        /// <param name="requestID">请求ID</param>
        /// <returns>状态</returns>
        public int StopPushLatestDatas(int requestID)
        {
            byte[] bytes = Encoding.UTF8.GetBytes("1");
            return Send(new CMessage(GroupID, ServiceID, FUNCTIONID_QUOTE_STOPPUSHLATESTDATA, SessionID, requestID, m_socketID, 0, CompressType, bytes.Length, bytes)) > 0 ? 1 : 0;
        }

        /// <summary>
        /// 发送历史数据请求
        /// </summary>
        /// <param name="functionID">功能ID</param>
        /// <param name="requestID">请求ID</param>
        /// <param name="socketID">连接ID</param>
        /// <param name="dataInfo">数据信息</param>
        /// <returns>状态</returns>
        public int Send(int functionID, int requestID, int socketID, HistoryDataInfo dataInfo)
        {
            Binary bw = new Binary();
            bw.WriteString(dataInfo.m_securityCode);
            bw.WriteChar((char)dataInfo.m_type);
            bw.WriteInt(dataInfo.m_size);
            bw.WriteInt(dataInfo.m_cycle);
            bw.WriteInt(dataInfo.m_subscription);
            bw.WriteDouble(dataInfo.m_startDate);
            bw.WriteDouble(dataInfo.m_endDate);
            bw.WriteBool(dataInfo.m_pushData);
            byte[] bytes = bw.GetBytes();
            int ret = Send(new CMessage(GroupID, ServiceID, functionID, SessionID, requestID, socketID, 0, CompressType, bytes.Length, bytes));
            bw.Close();
            return ret;
        }

        /// <summary>
        /// 发松最新数据请求
        /// </summary>
        /// <param name="functionID">功能ID</param>
        /// <param name="requestID">请求ID</param>
        /// <param name="socketID">连接ID</param>
        /// <param name="dataInfo">数据信息</param>
        /// <returns>状态</returns>
        public int Send(int functionID, int requestID, int socketID, LatestDataInfo dataInfo)
        {
            Binary bw = new Binary();
            bw.WriteString(dataInfo.m_codes);
            bw.WriteChar((char)dataInfo.m_formatType);
            bw.WriteChar((char)dataInfo.m_lv2);
            bw.WriteInt(dataInfo.m_size);
            byte[] bytes = bw.GetBytes();
            int ret = Send(new CMessage(GroupID, ServiceID, functionID, SessionID, requestID, socketID, 0, CompressType, bytes.Length, bytes));
            bw.Close();
            return ret;
        }
        #endregion
    }
}
