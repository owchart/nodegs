﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Text;

namespace LordStockAT
{
    /// <summary>
    /// 行情分时历史数据
    /// </summary>
    public class HistoryMinuteQuoteInfo : SecurityLatestData
    {
        /// <summary>
        /// 分时数据Day
        /// </summary>
        public String m_day = "";
        /// <summary>
        /// 分时数据备份字段
        /// </summary>
        public String m_quoteInfo = "";
        /// <summary>
        /// 分时数据时间
        /// </summary>
        public String m_time = "";

        /// <summary>
        /// 股票实时行情转换成行情分时历史数据
        /// </summary>
        /// <param name="latestData"></param>
        /// <returns></returns>
        public static HistoryMinuteQuoteInfo ConvertToHistoryMinuteQuoteInfo(SecurityLatestData latestData)
        {
            HistoryMinuteQuoteInfo info = new HistoryMinuteQuoteInfo();
            if (latestData == null)
            {
                return null;
            }
            info.m_amount = latestData.m_amount;
            info.m_buyVolume1 = latestData.m_buyVolume1;
            info.m_buyVolume2 = latestData.m_buyVolume2;
            info.m_buyVolume3 = latestData.m_buyVolume3;
            info.m_buyVolume4 = latestData.m_buyVolume4;
            info.m_buyVolume5 = latestData.m_buyVolume5;
            info.m_buyPrice1 = latestData.m_buyPrice1;
            info.m_buyPrice2 = latestData.m_buyPrice2;
            info.m_buyPrice3 = latestData.m_buyPrice3;
            info.m_buyPrice4 = latestData.m_buyPrice4;
            info.m_buyPrice5 = latestData.m_buyPrice5;
            info.m_close = latestData.m_close;
            info.m_date = latestData.m_date;
            info.m_day = latestData.m_day;
            info.m_high = latestData.m_high;
            info.m_innerVol = latestData.m_innerVol;
            info.m_lastClose = latestData.m_lastClose;
            info.m_low = latestData.m_low;
            info.m_open = latestData.m_open;
            info.m_openInterest = latestData.m_openInterest;
            info.m_outerVol = latestData.m_outerVol;
            info.m_securityCode = latestData.m_securityCode;
            info.m_securityName = latestData.m_securityName;
            info.m_sellVolume1 = latestData.m_sellVolume1;
            info.m_sellVolume2 = latestData.m_sellVolume2;
            info.m_sellVolume3 = latestData.m_sellVolume3;
            info.m_sellVolume4 = latestData.m_sellVolume4;
            info.m_sellVolume5 = latestData.m_sellVolume5;
            info.m_sellPrice1 = latestData.m_sellPrice1;
            info.m_sellPrice2 = latestData.m_sellPrice2;
            info.m_sellPrice3 = latestData.m_sellPrice3;
            info.m_sellPrice4 = latestData.m_sellPrice4;
            info.m_sellPrice5 = latestData.m_sellPrice5;
            info.m_settlePrice = latestData.m_settlePrice;
            info.m_time = latestData.m_time;
            info.m_turnoverRate = latestData.m_turnoverRate;
            info.m_volume = latestData.m_volume;
            info.m_quoteInfo = CStrA.SerializeObject(latestData);

            return info;
        }
    }

    /// <summary>
    /// 分时行情服务
    /// </summary>
    public class HistoryMinuteQuoteService : IDisposable
    {  
        /// <summary>
       /// 创建服务器服务
       /// </summary>
        public HistoryMinuteQuoteService()
        {
            CreateTable();
        }

        /// <summary>
        /// 销毁对象
        /// </summary>
        public void Dispose()
        {
        }

        /// <summary>
        /// 连接字符串
        /// </summary>
        private String m_connectStr = "";

        /// <summary>
        /// 建表SQL
        /// </summary>
        public const String CREATETABLESQL = "CREATE TABLE HISTORYMINUTEQUOTE(ID INTEGER PRIMARY KEY AUTOINCREMENT, SECURITYCODE, SECURITYNAME, CLOSE NUMERIC(16,4), HIGH NUMERIC(16,4), " +
            " LASTCLOSE NUMERIC(16,4), LOW NUMERIC(16,4), OPEN NUMERIC(16,4), VOLUME NUMERIC(16,4), AMOUNT INTEGER, DAY, TIME, QUOTEINFO TEXT)";

        /// <summary>
        /// 连接字符串
        /// </summary>
        public const String DATABASENAME = "HistoryMinuteQuote.db";

        /// <summary>
        /// 添加分时数据
        /// </summary>
        /// <param name="quoteInfo">分时数据</param>
        /// <returns>状态</returns>
        public int AddHistoryMinuteQuoteInfo(HistoryMinuteQuoteInfo quoteInfo)
        {
            String sql = String.Format("INSERT INTO HISTORYMINUTEQUOTE(SECURITYCODE, SECURITYNAME, CLOSE, HIGH, LASTCLOSE, LOW, OPEN, VOLUME, AMOUNT, DAY, TIME, QUOTEINFO) "
                + "values ('{0}','{1}', {2}, {3}, {4}, {5}, {6}, {7}, {8}, '{9}', '{10}', '{11}')",
                CStrA.GetDBString(quoteInfo.m_securityCode), CStrA.GetDBString(quoteInfo.m_securityName), quoteInfo.m_close, quoteInfo.m_high, quoteInfo.m_lastClose, quoteInfo.m_low
                , quoteInfo.m_open, quoteInfo.m_volume, quoteInfo.m_amount, CStrA.GetDBString(quoteInfo.m_day), CStrA.GetDBString(quoteInfo.m_time), CStrA.GetDBString(quoteInfo.m_quoteInfo));
            SQLiteConnection conn = new SQLiteConnection(m_connectStr);
            conn.Open();
            SQLiteCommand cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            int ret = cmd.ExecuteNonQuery();
            conn.Close();
            return 1;
        }

        /// <summary>
        /// 获取或设置是否需要创建表
        /// </summary>
        public void CreateTable()
        {
            String dataDir = DataCenter.GetAppPath() + "\\data";
            if (!CFileA.IsDirectoryExist(dataDir))
            {
                CFileA.CreateDirectory(dataDir);
            }
            String dataBasePath = dataDir + "\\" + DATABASENAME;
            m_connectStr = "Data Source = " + dataBasePath;
            if (!CFileA.IsFileExist(dataBasePath))
            {
                //创建数据库文件
                SQLiteConnection.CreateFile(dataBasePath);
                //创建表
                SQLiteConnection conn = new SQLiteConnection(m_connectStr);
                conn.Open();
                SQLiteCommand cmd = conn.CreateCommand();
                cmd.CommandText = CREATETABLESQL;
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        } 
        
        /// <summary>
        /// 获取分时数据
        /// </summary>
        /// <param name="quoteInfo">分时数据列表</param>
        /// <returns>状态</returns>
        public int GetHistoryMinuteQuoteInfoCount(HistoryMinuteQuoteInfo quoteInfo)
        {
            String sql = String.Format("SELECT * FROM HISTORYMINUTEQUOTE WHERE DAY = '{0}' AND TIME = '{1}'", 
                CStrA.GetDBString(quoteInfo.m_day), CStrA.GetDBString(quoteInfo.m_time));
            SQLiteConnection conn = new SQLiteConnection(m_connectStr);
            SQLiteCommand cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            conn.Open();
            int count = 0;
            SQLiteDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                count++;
            }
            reader.Close();
            conn.Close();
            return count;
        }

        /// <summary>
        /// 获取分时数据
        /// </summary>
        /// <param name="quoteInfos">分时数据列表</param>
        /// <returns>状态</returns>
        public int GetHistoryMinuteQuoteInfos(List<HistoryMinuteQuoteInfo> quoteInfos)
        {
            String sql = "SELECT * FROM HISTORYMINUTEQUOTE";
            SQLiteConnection conn = new SQLiteConnection(m_connectStr);
            SQLiteCommand cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            conn.Open();
            SQLiteDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int index = 1;
                HistoryMinuteQuoteInfo quoteInfo = new HistoryMinuteQuoteInfo();
                quoteInfo.m_securityCode = reader.GetString(index++);
                quoteInfo.m_securityName = reader.GetString(index++);
                quoteInfo.m_close = reader.GetFloat(index++);
                quoteInfo.m_high = reader.GetFloat(index++);
                quoteInfo.m_lastClose = reader.GetFloat(index++);
                quoteInfo.m_low = reader.GetFloat(index++);
                quoteInfo.m_open = reader.GetFloat(index++);
                quoteInfo.m_volume = reader.GetFloat(index++);
                quoteInfo.m_amount =reader.GetFloat(index++);
                quoteInfo.m_day = reader.GetString(index++);
                quoteInfo.m_time = reader.GetString(index++);
                quoteInfo.m_quoteInfo = reader.GetString(index++);
                quoteInfos.Add(quoteInfo);
            }
            reader.Close();
            conn.Close();
            return 1;
        }
    }
}
