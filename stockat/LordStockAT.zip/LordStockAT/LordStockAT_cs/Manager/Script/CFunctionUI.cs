/*******************************************************************************************\
*                                                                                           *
* CFunctionUI.cs -  UI functions, types, and definitions.                            *
*                                                                                           *
*               Version 1.00  ����                                                        *
*                                                                                           *
*               Copyright (c) 2016-2016, Piratecat. All rights reserved.                    *
*               Created by Lord 2016/10/17.                                                  *
*                                                                                           *
********************************************************************************************/

using OwLib;
using System;
using System.Windows.Forms;

namespace LordStockAT
{
    /// <summary>
    /// ������صĿ�
    /// </summary>
    public class CFunctionUI : CFunction
    {
        /// <summary>
        /// ��������
        /// </summary>
        /// <param name="indicator">ָ��</param>
        /// <param name="id">ID</param>
        /// <param name="name">����</param>
        /// <param name="withParameters">�Ƿ��в���</param>
        public CFunctionUI(CIndicator indicator, int id, String name, UIXml xml)
        {
            m_indicator = indicator;
            m_ID = id;
            m_name = name;
            m_xml = xml;
        }

        /// <summary>
        /// ָ��
        /// </summary>
        public CIndicator m_indicator;

        /// <summary>
        /// XML����
        /// </summary>
        public UIXml m_xml;

        /// <summary>
        /// ����
        /// </summary>
        private static string FUNCTIONS = "GETPROPERTY,SETPROPERTY,GETSENDER,ALERT,INVALIDATE,SHOWWINDOW,CLOSEWINDOW,STARTTIMER,STOPTIMER,GETCOOKIE,SETCOOKIE,SHOWRIGHTMENU,ADDBARRAGE";

        /// <summary>
        /// ǰ׺
        /// </summary>
        private static string PREFIX = "";

        /// <summary>
        /// ��ʼ����
        /// </summary>
        private const int STARTINDEX = 2000;

        /// <summary>
        /// ����
        /// </summary>
        /// <param name="var">����</param>
        /// <returns>���</returns>
        public override double OnCalculate(CVariable var)
        {
            switch (var.m_functionID)
            {
                case STARTINDEX + 0:
                    return GETPROPERTY(var);
                case STARTINDEX + 1:
                    return SETPROPERTY(var);
                case STARTINDEX + 2:
                    return GETSENDER(var);
                case STARTINDEX + 3:
                    return ALERT(var);
                case STARTINDEX + 4:
                    return INVALIDATE(var);
                case STARTINDEX + 5:
                    return SHOWWINDOW(var);
                case STARTINDEX + 6:
                    return CLOSEWINDOW(var);
                case STARTINDEX + 7:
                    return STARTTIMER(var);
                case STARTINDEX + 8:
                    return STOPTIMER(var);
                case STARTINDEX + 9:
                    return GETCOOKIE(var);
                case STARTINDEX + 10:
                    return SETCOOKIE(var);
                case STARTINDEX + 11:
                    return SHOWRIGHTMENU(var);
                case STARTINDEX + 12:
                    return ADDBARRAGE(var);
                default:
                    return 0;
            }
        }

        /// <summary>
        /// ���ӷ���
        /// </summary>
        /// <param name="indicator">������</param>
        /// <param name="native">�ű�</param>
        /// <param name="xml">XML</param>
        /// <returns>ָ��</returns>
        public static void AddFunctions(CIndicator indicator, UIXml xml)
        {
            string[] functions = FUNCTIONS.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
            int functionsSize = functions.Length;
            for (int i = 0; i < functionsSize; i++)
            {
                indicator.AddFunction(new CFunctionUI(indicator, STARTINDEX + i, PREFIX + functions[i], xml));
            }
        }

        /// <summary>
        /// ��ʾ
        /// </summary>
        /// <param name="var">����</param>
        /// <returns>���</returns>
        public double ADDBARRAGE(CVariable var)
        {
            string text = "";
            int len = var.m_parameters.Length;
            for (int i = 0; i < len; i++)
            {
                text += m_indicator.GetText(var.m_parameters[i]);
            }
            BarrageDiv barrageDiv = (m_xml as MainFrame).FindControl("divBarrage") as BarrageDiv;
            Barrage barrage = new Barrage();
            barrage.Text = text;
            barrage.Mode = 0;
            barrageDiv.AddBarrage(barrage);
            return 1;
        }

        /// <summary>
        /// ������ʾ
        /// </summary>
        /// <param name="var">����</param>
        /// <returns>״̬</returns>
        private double ALERT(CVariable var)
        {
            double result = 0;
            int len = var.m_parameters.Length;
            if (len == 1)
            {
                if (DialogResult.OK == MessageBox.Show(m_indicator.GetText(var.m_parameters[0])))
                {
                    result = 1;
                }
            }
            else
            {
                if (DialogResult.OK == MessageBox.Show(m_indicator.GetText(var.m_parameters[0]),
                    m_indicator.GetText(var.m_parameters[1])))
                {
                    result = 1;
                }
            }
            return result;
        }


        /// <summary>
        /// ��ȡCOOKIE
        /// </summary>
        /// <param name="var">����</param>
        /// <returns>״̬</returns>
        private double GETCOOKIE(CVariable var)
        {
            string cookieName = m_indicator.GetText(var.m_parameters[1]);
            UserCookieService cookieService = DataCenter.UserCookieService;
            UserCookie cookie = new UserCookie();
            if (cookieService.GetCookie(cookieName, ref cookie) > 0)
            {
                CVariable newVar = new CVariable(m_indicator);
                newVar.m_expression = "'" + cookie.m_value + "'";
                m_indicator.SetVariable(var.m_parameters[0], newVar);
                return 1;
            }
            return 0;
        }

        /// <summary>
        /// ��ȡ����
        /// </summary>
        /// <param name="var">����</param>
        /// <returns>״̬</returns>
        public double GETPROPERTY(CVariable var)
        {
            GaiaScript gaiaScript = m_xml.Script as GaiaScript;
            string name = m_indicator.GetText(var.m_parameters[1]);
            string propertyName = m_indicator.GetText(var.m_parameters[2]);
            string text = gaiaScript.GetProperty(name, propertyName);
            CVariable newVar = new CVariable(m_indicator);
            newVar.m_expression = "'" + text + "'";
            m_indicator.SetVariable(var.m_parameters[0], newVar);
            return 0;
        }

        /// <summary>
        /// ��ȡ������
        /// </summary>
        /// <param name="var">����</param>
        /// <returns>״̬</returns>
        public double GETSENDER(CVariable var)
        {
            GaiaScript gaiaScript = m_xml.Script as GaiaScript;
            string text = gaiaScript.GetSender();
            CVariable newVar = new CVariable(m_indicator);
            newVar.m_expression = "'" + text + "'";
            m_indicator.SetVariable(var.m_parameters[0], newVar);
            return 0;
        }

        /// <summary>
        /// ˢ�½���
        /// </summary>
        /// <param name="var">����</param>
        /// <returns>״̬</returns>
        private double INVALIDATE(CVariable var)
        {
            if (m_xml != null)
            {
                int pLen = var.m_parameters != null ? var.m_parameters.Length : 0;
                if (pLen == 0)
                {
                    m_xml.Native.Invalidate();
                }
                else
                {
                    ControlA control = m_xml.FindControl(m_indicator.GetText(var.m_parameters[0]));
                    if (control != null)
                    {
                        control.Invalidate();
                    }
                }
            }
            return 0;
        }

        /// <summary>
        /// ����COOKIE
        /// </summary>
        /// <param name="var">����</param>
        /// <returns>���</returns>
        private double SETCOOKIE(CVariable var)
        {
            string cookieName = m_indicator.GetText(var.m_parameters[0]);
            UserCookieService cookieService = DataCenter.UserCookieService;
            UserCookie cookie = new UserCookie();
            cookie.m_key = cookieName;
            cookie.m_value = m_indicator.GetText(var.m_parameters[1]);
            return cookieService.AddCookie(cookie);
        }


        /// <summary>
        /// ��������
        /// </summary>
        /// <param name="var">����</param>
        /// <returns>״̬</returns>
        private double SETPROPERTY(CVariable var)
        {
            GaiaScript gaiaScript = m_xml.Script as GaiaScript;
            string name = m_indicator.GetText(var.m_parameters[0]);
            string propertyName = m_indicator.GetText(var.m_parameters[1]);
            string propertyValue = m_indicator.GetText(var.m_parameters[2]);
            gaiaScript.SetProperty(name, propertyName, propertyValue);
            return 0;
        }

        /// <summary>
        /// �رմ���
        /// </summary>
        /// <param name="var">����</param>
        /// <returns>״̬</returns>
        private double CLOSEWINDOW(CVariable var)
        {
           WindowXmlEx windowXmlEx = m_xml as WindowXmlEx;
            if (windowXmlEx != null)
            {
                windowXmlEx.Close();
            }
            return 0;
        }

        /// <summary>
        /// ��ʾ�Ҽ��˵�
        /// </summary>
        /// <param name="var">����</param>
        /// <returns>״̬</returns>
        private double SHOWRIGHTMENU(CVariable var)
        {
            GaiaScript gaiaScript = m_xml.Script as GaiaScript;
            INativeBase native = m_xml.Native;
            ControlA control = m_xml.FindControl(gaiaScript.GetSender());
            int clientX = native.ClientX(control);
            int clientY = native.ClientY(control);
            MenuA menu = m_xml.GetMenu(m_indicator.GetText(var.m_parameters[0]));
            menu.Location = new POINT(clientX, clientY + control.Height);
            menu.Visible = true;
            menu.Focused = true;
            menu.BringToFront();
            native.Invalidate();
            return 0;
        }

        /// <summary>
        /// ��ʾ����
        /// </summary>
        /// <param name="var">����</param>
        /// <returns>״̬</returns>
        private double SHOWWINDOW(CVariable var)
        {
            string xmlName = m_indicator.GetText(var.m_parameters[0]);
            string windowName = m_indicator.GetText(var.m_parameters[1]);
            WindowXmlEx window = new WindowXmlEx();
            window.Load(m_xml.Native, xmlName, windowName);
            window.Show();
            if (xmlName == "HotKeyWindow")
            {
                TextBoxA txtKey = window.GetTextBox("txtHotKey");
                txtKey.Text = "�����������¿�ݼ���\r1. F1-F3  --> ���ٳ���100-300Ԫ\r2. F4-F10 --> ���ٷ���400-1000Ԫ\r3. F11    --> ����   \rHome   --> ����   \rEnd    --> ȡ������   \rEnter  --> �ύ��֤��   \rEsc    --> �ֶ���������4. ����������������������ٵ����۸�";
            }
            return 0;
        }

        /// <summary>
        /// ��ʼ���
        /// </summary>
        /// <param name="var">����</param>
        /// <returns>״̬</returns>
        private double STARTTIMER(CVariable var)
        {
            ControlA control = m_xml.FindControl(m_indicator.GetText(var.m_parameters[0]));
            control.StartTimer((int)m_indicator.GetValue(var.m_parameters[1]), (int)m_indicator.GetValue(var.m_parameters[2]));
            return 0;
        }

        /// <summary>
        /// �������
        /// </summary>
        /// <param name="var">����</param>
        /// <returns>״̬</returns>
        private double STOPTIMER(CVariable var)
        {
            ControlA control = m_xml.FindControl(m_indicator.GetText(var.m_parameters[0]));
            control.StopTimer((int)m_indicator.GetValue(var.m_parameters[1]));
            return 0;
        }
    }
}