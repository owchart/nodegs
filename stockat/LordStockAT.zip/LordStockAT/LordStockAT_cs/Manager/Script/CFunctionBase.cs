/*******************************************************************************************\
*                                                                                           *
* CFunctionBase.cs -  Base functions, types, and definitions.                            *
*                                                                                           *
*               Version 1.00  ����                                                        *
*                                                                                           *
*               Copyright (c) 2016-2016, Piratecat. All rights reserved.                    *
*               Created by Lord 2016/10/17.                                                  *
*                                                                                           *
********************************************************************************************/

using OwLib;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace LordStockAT
{
    /// <summary>
    /// ������صĿ�
    /// </summary>
    public class CFunctionBase : CFunction
    {
        /// <summary>
        /// ��������
        /// </summary>
        /// <param name="indicator">ָ��</param>
        /// <param name="id">ID</param>
        /// <param name="name">����</param>
        /// <param name="withParameters">�Ƿ��в���</param>
        public CFunctionBase(CIndicator indicator, int id, String name, INativeBase native)
        {
            m_indicator = indicator;
            m_ID = id;
            m_name = name;
            m_native = native;
        }

        /// <summary>
        /// ָ��
        /// </summary>
        public CIndicator m_indicator;

        /// <summary>
        /// XML����
        /// </summary>
        public INativeBase m_native;

        /// <summary>
        /// ����
        /// </summary>
        private static string FUNCTIONS = "IN,OUT,SLEEP";

        /// <summary>
        /// ǰ׺
        /// </summary>
        private static string PREFIX = "";

        /// <summary>
        /// ��ʼ����
        /// </summary>
        private const int STARTINDEX = 1000;

        /// <summary>
        /// ����
        /// </summary>
        /// <param name="var">����</param>
        /// <returns>���</returns>
        public override double OnCalculate(CVariable var)
        {
            switch (var.m_functionID)
            {
                case STARTINDEX + 0:
                    return IN(var);
                case STARTINDEX + 1:
                    return OUT(var);
                case STARTINDEX + 2:
                    return SLEEP(var);
                default: return 0;
            }
        }

        /// <summary>
        /// ���ӷ���
        /// </summary>
        /// <param name="indicator">������</param>
        /// <param name="native">�ű�</param>
        /// <param name="xml">XML</param>
        /// <returns>ָ��</returns>
        public static void AddFunctions(CIndicator indicator, INativeBase native)
        {
            string[] functions = FUNCTIONS.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
            int functionsSize = functions.Length;
            for (int i = 0; i < functionsSize; i++)
            {
                indicator.AddFunction(new CFunctionBase(indicator, STARTINDEX + i, PREFIX + functions[i], native));
            }
        }

        /// <summary>
        /// ���뺯��
        /// </summary>
        /// <param name="var">����</param>
        /// <returns>״̬</returns>
        private double IN(CVariable var)
        {
            CVariable newVar = new CVariable(m_indicator);
            newVar.m_expression = "'" + Console.ReadLine() + "'";
            m_indicator.SetVariable(var.m_parameters[0], newVar);
            return 0;
        }

        /// <summary>
        /// �������
        /// </summary>
        /// <param name="var">����</param>
        /// <returns>״̬</returns>
        private double OUT(CVariable var)
        {
            int len = var.m_parameters.Length;
            for (int i = 0; i < len; i++)
            {
                string text = m_indicator.GetText(var.m_parameters[i]);
                Console.Write(text);
            }
            Console.WriteLine("");
            return 0;
        }

        /// <summary>
        /// ˯��
        /// </summary>
        /// <param name="var">����</param>
        /// <returns>״̬</returns>
        private double SLEEP(CVariable var)
        {
            Thread.Sleep((int)m_indicator.GetValue(var.m_parameters[0]));
            return 1;
        }
    }
}
