/*****************************************************************************\
*                                                                             *
* AutoTrade.h -        AutoTrade functions, types, and definitions.           *
*                                                                             *
*               Version 1.00 ��                                               *
*                                                                             *
*               Copyright (c) 2016-2016, Trade. All rights reserved.          *
*               Created by Lord 2016/8/4.                                     *
*               //ע��:ͬ��˳ί��ǰ�Ƿ���Ҫȷ��Ҫȥ����Ĭ�ϼ۸�ȥ�� 
*				��������ί���ѳɹ��ύȥ��
******************************************************************************/
#ifndef __AUTOTRADE_H__
#define __AUTOTRADE_H__
#pragma once
#include "stdafx.h"

class OrderInfo
{
public:
	String m_code;
	double m_price;
	int m_qty;
public:
	OrderInfo()
	{
		m_code = L"";
		m_price = 0;
		m_qty = 0;
	}
};

class WindowInfo
{
public:
	String m_className;
    HWND m_hWnd;
    RECT m_rect;
    String m_text;
public:
	WindowInfo()
	{
		m_className = L"";
		m_rect.left = 0;
		m_rect.top = 0;
		m_rect.right = 0;
		m_rect.bottom = 0;
		m_text = L"";
	}
};

class AutoTrade
{
public:
	AutoTrade();
	virtual ~AutoTrade();
};
extern "C" __declspec(dllexport) int AddOrder(char *code, double price, int qty);
extern "C" __declspec(dllexport) int StartOrder();


#endif