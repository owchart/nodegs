#pragma once

#include "CLRHostProxy.h"
 
#define DEF_FW_VERSION2_0	2
#define DEF_FW_VERSION4_0	4
struct stOnceFlag;
class CCLRHostProxyWrapper
{
public:
	CCLRHostProxyWrapper(void);
	~CCLRHostProxyWrapper(void);


	static CCLRHostProxyWrapper* GetInstance();
	static void ReleaseInstance();
	
	void Start(LPCWSTR pwzAssemblyPath, LPCWSTR pwzTypeName, LPCWSTR pwzMethodName, LPCWSTR pwzArgument, DWORD *pReturnValue);
private:
	void LoadCLR();
  
	CCLRHostProxyBase		* m_pCLRHostProxy;
	short m_sCLRHostProxyType;
	static stOnceFlag	g_stOnceFlag;
	static CCLRHostProxyWrapper* g_CLRHostProxyWrapper;
};

