#include "StdAfx.h"
#include "CLRHostProxy.h"
 
#include <mscoree.h>  
#pragma comment(lib, "mscoree.lib")  
CCLRHostProxy::CCLRHostProxy(void)
{
    bCLRIsInitialized = false;
    pMetaHost = nullptr; 
    pMetaHostPolicy = nullptr; 
    pRuntimeHost = nullptr; 
    pRuntimeInfo = nullptr; 

   // LoadCLR();
}


CCLRHostProxy::~CCLRHostProxy(void)
{
    ReleaseCLR();
}

void CCLRHostProxy::Start(LPCWSTR pwzAssemblyPath,
    LPCWSTR pwzTypeName, 
    LPCWSTR pwzMethodName,
    LPCWSTR pwzArgument,
    DWORD *pReturnValue)
{
    if (!bCLRIsInitialized)
    {
		//AfxMessageBox(_T("return"));
        return;
    }

    HRESULT hr; 
    hr = pRuntimeHost->ExecuteInDefaultAppDomain(
        pwzAssemblyPath, 
        pwzTypeName,   
        pwzMethodName, 
        pwzArgument, 
        pReturnValue); 

    /*HRESULT hr;
    DWORD dwRet = 0; 
    hr = pRuntimeHost->ExecuteInDefaultAppDomain(
    L"D:\\EastMoney\\EMPTS\\Source\\EMUI\\Debug\\SampleManagedApp.exe", 
    L"SampleManagedApp.Form1",   
    L"Test", 
    L"Hello World!", 
    &dwRet); 
    */

 
}


BOOL CCLRHostProxy::CheckCLRCreateInstance()
{
	BOOL bRet = TRUE;
	try
	{
		
		typedef HRESULT (*CLRCreateInstanceFuc)(REFCLSID , REFIID , /*iid_is(riid)*/ LPVOID );

		HINSTANCE hInstance = LoadLibrary(_T("mscoree.dll"));                    //���ڼ���dll

		CLRCreateInstanceFuc MyCLRCreateInstanceFuc = (CLRCreateInstanceFuc)GetProcAddress(hInstance, "CLRCreateInstance"); 

		DWORD dwEr = GetLastError();


		if(!MyCLRCreateInstanceFuc)
		{
			bRet = FALSE;
			//AfxMessageBox(_T("û���ҵ�"));
		}

		FreeLibrary(hInstance);                
	}
	catch (...)
	{
		bRet = FALSE;
	}
	        
	return bRet;
}
DWORD CCLRHostProxy::LoadCLR()
{
	DWORD dwRet = 0;
    HRESULT hr;
	 
// 	if(CheckCLRCreateInstance() == FALSE)
// 	{
// 		return 0;
// 	}
// 	AfxMessageBox(_T("�ҵ� CLRCreateInstance"));
	 
	hr = CoInitialize(NULL);

	typedef HRESULT (__stdcall *CLRCreateInstanceFuc)(REFCLSID , REFIID , /*iid_is(riid)*/ LPVOID );

	HINSTANCE hInstance = LoadLibrary(_T("mscoree.dll"));                    //���ڼ���dll

	if(hInstance)
	{
		CLRCreateInstanceFuc MyCLRCreateInstanceFuc = (CLRCreateInstanceFuc)GetProcAddress(hInstance, "CLRCreateInstance"); 

		if(MyCLRCreateInstanceFuc)
		{
			hr = (*MyCLRCreateInstanceFuc)(CLSID_CLRMetaHost, IID_ICLRMetaHost, (LPVOID*)&pMetaHost); 

			//hr = CLRCreateInstance(CLSID_CLRMetaHost, IID_ICLRMetaHost, (LPVOID*)&pMetaHost); 
		}

		FreeLibrary(hInstance);
	}
	          
    //hr = CLRCreateInstance(CLSID_CLRMetaHost, IID_ICLRMetaHost, (LPVOID*)&pMetaHost); 
	 
    if(FAILED(hr)) 
    { 
		dwRet = GetLastError();

        return dwRet;
    } 

    hr = pMetaHost->GetRuntime(L"v4.0.30319", IID_PPV_ARGS(&pRuntimeInfo)); 
    //hr = pMetaHost->GetRuntime(L"v2.0.50727", IID_PPV_ARGS(&pRuntimeInfo)); 
    if(FAILED(hr)) 
    { 
		dwRet = GetLastError();

		return dwRet;
    } 

    hr = pRuntimeInfo->GetInterface(CLSID_CLRRuntimeHost, IID_PPV_ARGS(&pRuntimeHost)); 
    if(FAILED(hr)) 
	{ 
		dwRet = GetLastError();

		return dwRet;
	} 

	hr = pRuntimeHost->Start(); 
	if(FAILED(hr)) 
	{ 
		dwRet = GetLastError();

		return dwRet;
    } 

    bCLRIsInitialized = true;
    
	return dwRet ;
}

void CCLRHostProxy::ReleaseCLR()
{
    if(pRuntimeInfo != nullptr) 
    { 
        pRuntimeInfo->Release(); 
        pRuntimeInfo = nullptr; 
    } 

    if(pRuntimeHost != nullptr) 
    { 
        pRuntimeHost->Stop();
        pRuntimeHost->Release(); 
        pRuntimeHost = nullptr; 
    } 

    if(pMetaHost != nullptr) 
    { 
        pMetaHost->Release(); 
        pMetaHost = nullptr; 
    } 
}
 
//////////////////////////////////////////////////////////////////////////

CCLRHostProxy20::CCLRHostProxy20(void)
{
	m_pClrRuntimeHost = NULL;

	m_bInit = false;
	//LoadCLR();
}


CCLRHostProxy20::~CCLRHostProxy20(void)
{
	if(m_bInit)
		m_pClrRuntimeHost->Stop();
}


DWORD CCLRHostProxy20::LoadCLR()
{
	PCWSTR pszVersion = L"v2.0.50727";
	PCWSTR pszFlavor = L"wks";
	PCWSTR pszRuntimeModule = L"mscorwks";

	HRESULT hr = CorBindToRuntimeEx(
		pszVersion,
		pszFlavor,
		0,
		CLSID_CLRRuntimeHost,
		IID_PPV_ARGS(&m_pClrRuntimeHost)
		);
	if(FAILED(hr)){
		DWORD dwErr = GetLastError();

		return dwErr;
	}

	hr = m_pClrRuntimeHost->Start();

	if(FAILED(hr))
	{
		DWORD dwErr = GetLastError();

		return dwErr;
	}

	m_bInit = true;
	return 0;
}

void CCLRHostProxy20::Start(LPCWSTR pwzAssemblyPath,
	LPCWSTR pwzTypeName, 
	LPCWSTR pwzMethodName,
	LPCWSTR pwzArgument,
	DWORD *pReturnValue)
{

	HRESULT hr; 
	hr = m_pClrRuntimeHost->ExecuteInDefaultAppDomain(
		pwzAssemblyPath, 
		pwzTypeName,   
		pwzMethodName, 
		pwzArgument, 
		pReturnValue); 

}