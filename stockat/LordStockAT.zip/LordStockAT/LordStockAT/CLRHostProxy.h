#pragma once

#include <SDKDDKVer.h>  

#include <stdio.h>  
#include <tchar.h>  
#include <windows.h>  

#include <metahost.h>  
 
class CCLRHostProxyBase
{
public:
	CCLRHostProxyBase(){}
	~CCLRHostProxyBase(){}

	virtual DWORD LoadCLR() = 0;
	virtual void Start(LPCWSTR pwzAssemblyPath,
		LPCWSTR pwzTypeName, 
		LPCWSTR pwzMethodName,
		LPCWSTR pwzArgument,
		DWORD *pReturnValue) = 0;
};
class CCLRHostProxy : public CCLRHostProxyBase
{
private:
    bool bCLRIsInitialized;
    ICLRMetaHost        *pMetaHost ; 
    ICLRMetaHostPolicy  *pMetaHostPolicy ; 
    ICLRRuntimeHost     *pRuntimeHost ; 
    ICLRRuntimeInfo     *pRuntimeInfo ; 
   
    void ReleaseCLR();
	 
public:
    ~CCLRHostProxy(void);
	 CCLRHostProxy(void);
public:
	virtual DWORD LoadCLR();
    virtual void Start(LPCWSTR pwzAssemblyPath,
        LPCWSTR pwzTypeName, 
        LPCWSTR pwzMethodName,
        LPCWSTR pwzArgument,
        DWORD *pReturnValue);
	BOOL CheckCLRCreateInstance();
};
 
//////////////////////////////////////////////////////////////////////////
// #include <mscoree.h>  
// #pragma comment(lib, "mscoree.lib")  
#import "mscorlib.tlb" raw_interfaces_only \
	high_property_prefixes("_get","_put","_putref") \
	rename("ReportEvent","InteropServices_ReportEvent")
class CCLRHostProxy20 : public CCLRHostProxyBase
{
public:
	CCLRHostProxy20(void);
	~CCLRHostProxy20(void);

	virtual DWORD LoadCLR();
	virtual void Start(LPCWSTR pwzAssemblyPath, LPCWSTR pwzTypeName, LPCWSTR pwzMethodName, LPCWSTR pwzArgument, DWORD *pReturnValue);
private:

	ICLRRuntimeHost * m_pClrRuntimeHost;

	bool m_bInit;
};
