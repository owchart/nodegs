#include "stdafx.h"
#include "AutoTrade.h"
#include "AppHost.h"

vector<WindowInfo> m_allWindows;
vector<WindowInfo> m_childWindows;
vector<OrderInfo> m_orderInfos;

void stringTowstring(String &strDest, const string& strSrc)
{
	int  unicodeLen = ::MultiByteToWideChar(CP_ACP, 0, strSrc.c_str(), -1, 0, 0);
	wchar_t *pUnicode = new  wchar_t[unicodeLen + 1];
	memset(pUnicode,0,(unicodeLen + 1) * sizeof(wchar_t));
	::MultiByteToWideChar(CP_ACP, 0, strSrc.c_str(), - 1, (LPWSTR)pUnicode, unicodeLen);
	strDest = ( wchar_t* )pUnicode;
	delete[] pUnicode;
}

void wstringTostring(string &strDest, const String& strSrc)
{
	int iTextLen = WideCharToMultiByte(CP_ACP, 0, strSrc.c_str(), -1, NULL, 0, NULL, NULL);
	char *pElementText = new char[iTextLen + 1];
	memset( ( void* )pElementText, 0, sizeof( char ) * ( iTextLen + 1 ) );
	::WideCharToMultiByte(CP_ACP, 0, strSrc.c_str(), - 1, pElementText, iTextLen, 0, 0);
	strDest = pElementText;
	delete[] pElementText;
}

String GetText(HWND hWnd)
{
	if(hWnd)
	{
		SendMessageTimeout(hWnd, 0xD, 0, (LPARAM)"Environment", 0x0002, 2000, 0);
		wchar_t temp[10240] = {0};
		SendMessage(hWnd, 0xD, sizeof(temp) / sizeof(wchar_t), (LPARAM)temp);
		return temp;
	}
	return L"";
}

void MouseEvent(String eventID, int dx, int dy, int data)
{
	DWORD flag = MOUSEEVENTF_MOVE;
	if(eventID == L"SETCURSOR")
	{
		SetCursorPos(dx, dy);
		return;
	}
    else if(eventID == L"MOVE")
    {
        flag = MOUSEEVENTF_MOVE;
    }
    else if(eventID == L"LEFTDOWN")
    {
        flag = MOUSEEVENTF_LEFTDOWN;
    }
    else if(eventID == L"LEFTUP")
    {
        flag = MOUSEEVENTF_LEFTUP;
    }
    else if(eventID == L"RIGHTDOWN")
    {
        flag = MOUSEEVENTF_RIGHTDOWN;
    }
	else if(eventID == L"RIGHTUP")
    {
        flag = MOUSEEVENTF_RIGHTUP;
    }
    else if(eventID == L"MIDDLEDOWN")
    {
        flag = MOUSEEVENTF_MIDDLEDOWN;
    }
    else if(eventID == L"MIDDLEUP")
    {
        flag = MOUSEEVENTF_MIDDLEUP;
    }
    else if(eventID == L"XDOWN")
    {
        flag = MOUSEEVENTF_XDOWN;
    }
    else if(eventID == L"XUP")
    {
        flag = MOUSEEVENTF_XUP;
    }
    else if(eventID == L"WHEEL")
    {
        flag = MOUSEEVENTF_WHEEL;
    }
    else if (eventID == L"VIRTUALDESK")
    {
        flag = MOUSEEVENTF_VIRTUALDESK;
    }
    else if (eventID == L"ABSOLUTE")
    {
        flag = MOUSEEVENTF_ABSOLUTE;
    }
	mouse_event(flag, dx, dy, data, 0);
}

void SendKey(int key)
{
	wchar_t sz[1024] = {0};
	_stprintf_s(sz, 1023, L"%d", key);
	AppHost::SendKey(sz);
}

void SetText(HWND hWnd, String text)
{
	string sText = "";
	wstringTostring(sText, text);
	SendMessage(hWnd, 0x000C, 0, (LPARAM)text.c_str());
}

////////////////////////////////////////////////////////////////////////////////////////////

AutoTrade::AutoTrade()
{
}

AutoTrade::~AutoTrade()
{
}

///////////////////////////////////////////////////////////////////////////////////////////

BOOL CALLBACK GetChildWindowsCallBack(HWND hwnd,LPARAM lParam)
{
	wchar_t sb[256] = {0};
    GetClassName(hwnd, sb, 256); 
	RECT rect = {0};
    GetWindowRect(hwnd, &rect);
    WindowInfo windowInfo;
    windowInfo.m_className = sb;
    windowInfo.m_hWnd = hwnd;
    windowInfo.m_rect = rect;
    windowInfo.m_text = GetText(hwnd);
	m_childWindows.push_back(windowInfo);
    return true;
}

BOOL CALLBACK GetWindowsCallBack(HWND hwnd,LPARAM lParam)
{
	RECT rect = {0};
    GetWindowRect(hwnd, &rect);
    WindowInfo windowInfo;
    windowInfo.m_hWnd = hwnd;
    windowInfo.m_rect = rect;
    windowInfo.m_text = GetText(hwnd);
	m_allWindows.push_back(windowInfo);
    return true;
}

void GetChildWindows(HWND hWnd, vector<WindowInfo> *childWindows)
{
    EnumChildWindows(hWnd, GetChildWindowsCallBack, 0);
	vector<WindowInfo>::iterator sIter = m_childWindows.begin();
	for(; sIter != m_childWindows.end(); ++sIter)
	{
		childWindows->push_back(*sIter);
	}
	m_childWindows.clear();
}

void GetWindows(vector<WindowInfo> *windows)
{
	EnumWindows(GetWindowsCallBack, 0);
	vector<WindowInfo>::iterator sIter = m_allWindows.begin();
	for(; sIter != m_allWindows.end(); ++sIter)
	{
		windows->push_back(*sIter);
	}
	m_allWindows.clear();
}

///////////////////////////////////////////////////////////////////////////////////////////

extern "C" __declspec(dllexport) int AddOrder(char *code, double price, int qty)
{
	String wCode = L"";
	stringTowstring(wCode, code);
	OrderInfo orderInfo;
    orderInfo.m_code = wCode;
    orderInfo.m_price = price;
    orderInfo.m_qty = qty;
	m_orderInfos.push_back(orderInfo);
	return 1;
}

int CheckPopupWindow(String title, String submitText, map<HWND, int> *keys)
{
	bool hasPopup = false;
    while (!hasPopup)
    {
        vector<WindowInfo> popupWindows2;
        GetWindows(&popupWindows2);
		int popupWindows2Size = (int)popupWindows2.size();
		for(int z = 0; z < popupWindows2Size; z++)
        {
			WindowInfo info = popupWindows2[z];
			if (keys->find(info.m_hWnd) == keys->end())
            {
                (*keys)[info.m_hWnd] = 0;
                vector<WindowInfo> popupChildWindows;
                GetChildWindows(info.m_hWnd, &popupChildWindows);
				int popupChildWindowsSize = (int)popupChildWindows.size();
                WindowInfo submitButton;
                if (popupChildWindowsSize > 0)
                {
                    for(int x = 0; x < popupChildWindowsSize; x++)
                    {
						WindowInfo pChildWindow = popupChildWindows[x];
						if (pChildWindow.m_text.find(title) != -1)
                        {
                            hasPopup = true;
                        }
                        else if (pChildWindow.m_text == submitText)
                        {
                            submitButton = pChildWindow;
                        }
                    }
                }
                if (hasPopup)
                {
					MouseEvent(L"SETCURSOR", submitButton.m_rect.left + 5, submitButton.m_rect.top + 5, 0);
                    MouseEvent(L"LEFTDOWN", 0, 0, 0);
                    MouseEvent(L"LEFTUP", 0, 0, 0);
                }
            }
        }
        Sleep(100);
    }
	return 0;
}

extern "C" __declspec(dllexport) int StartOrder()
{
	vector<WindowInfo> windowInfos;
	GetWindows(&windowInfos);
	int windowInfosSize = (int)windowInfos.size();
    for (int i = 0; i < windowInfosSize; i++)
    {
        //ͬ��˳�µ�
        if (windowInfos[i].m_text == L"���Ϲ�Ʊ����ϵͳ5.0")
        {
			vector<WindowInfo> childWindowInfos;
            GetChildWindows(windowInfos[i].m_hWnd, &childWindowInfos);
			int childWindowInfosSize = (int)childWindowInfos.size();
			int orderInfosSize = m_orderInfos.size();
			for (int u = 0; u < orderInfosSize; u++)
            {
				HWND priceHandle = 0;
				int editIndex = 0;
				bool canBuy = false;
				OrderInfo orderInfo = m_orderInfos[u];
				WindowInfo buyButton;
				for (int j = 0; j < childWindowInfosSize; j++)
				{
					WindowInfo childWindowInfo = childWindowInfos[j];
					if (childWindowInfo.m_className == L"Edit")
					{
						if (editIndex == 0)
						{
							SetText(childWindowInfo.m_hWnd, orderInfo.m_code);
						}
						else if (editIndex == 1)
						{
							priceHandle = childWindowInfo.m_hWnd;
							String text = GetText(childWindowInfo.m_hWnd);
							int wait = 15;
							while (text.length() == 0 && wait > 0)
							{
								text = GetText(childWindowInfo.m_hWnd);
								Sleep(100);
								wait--;
							}
							if ((int)text.length() > 0)
							{
								canBuy = true;
								if(orderInfo.m_price > 0)
								{
									wchar_t strPrice[1024] = {0};
									_stprintf_s(strPrice, 1024, L"%.3f", orderInfo.m_price);
									SetText(childWindowInfo.m_hWnd, strPrice);
								}
							}
						}
						else if (editIndex == 2)
						{
							wchar_t strQty[1024] = {0};
							_stprintf_s(strQty, 1024, L"%d", orderInfo.m_qty);
							SetText(childWindowInfo.m_hWnd, strQty);
						}
						editIndex++;
					}
					else if (childWindowInfo.m_className == L"Button")
					{
						if (childWindowInfo.m_text == L"����[B]")
						{
							buyButton = childWindowInfo;
						}
					}
				}
				if (canBuy)
				{
					if (orderInfo.m_price > 0)
                    {
						wchar_t strQty[1024] = {0};
						_stprintf_s(strQty, 1024, L"%d", orderInfo.m_qty);
						String newText = strQty;
                        if (newText != GetText(priceHandle))
                        {
                            SetText(priceHandle, newText);
                        }
                    }
					
					vector<WindowInfo> popupWindows;
                    GetWindows(&popupWindows);
                    map<HWND, int> keys;
                    int popupWindowsSize = (int)popupWindows.size();
                    for (int j = 0; j < popupWindowsSize; j++)
                    {
                        keys[popupWindows[j].m_hWnd] = 0;
                    }
					MouseEvent(L"SETCURSOR", buyButton.m_rect.left + 5, buyButton.m_rect.top + 5, 0);
                    MouseEvent(L"LEFTDOWN", 0, 0, 0);
                    MouseEvent(L"LEFTUP", 0, 0, 0);
                    CheckPopupWindow(L"���Ƿ�ȷ����������ί�У�", L"��(&Y)", &keys);
                    CheckPopupWindow(L"��������ί���ѳɹ��ύ", L"ȷ��", &keys);
					SendKey(13);
					Sleep(100);
					SendKey(13);
					Sleep(100);
				}
			}
            break;
        }
        //ͨ�����µ�
		else if (windowInfos[i].m_text.find(L"ͨ�������Ͻ���V6.20") == 0)
        {
			vector<WindowInfo> childWindowInfos;
			GetChildWindows(windowInfos[i].m_hWnd, &childWindowInfos);
			int childWindowInfosSize = (int)childWindowInfos.size();
			int orderInfosSize = m_orderInfos.size();
			for (int u = 0; u < orderInfosSize; u++)
            {
				HWND priceHandle = 0;
				int editIndex = 0;
				bool canBuy = false;
				OrderInfo orderInfo = m_orderInfos[u];
				WindowInfo buyButton;
				for (int j = 0; j < childWindowInfosSize; j++)
				{
					WindowInfo childWindowInfo = childWindowInfos[j];
					if (childWindowInfo.m_className == L"Edit")
					{
						if (editIndex == 0)
						{
							SetText(childWindowInfo.m_hWnd, orderInfo.m_code);
						}
						else if (editIndex == 1)
						{
							priceHandle = childWindowInfo.m_hWnd;
							String text = GetText(childWindowInfo.m_hWnd);
							int wait = 15;
							while (text.length() == 0 && wait > 0)
							{
								text = GetText(childWindowInfo.m_hWnd);
								Sleep(100);
								wait--;
							}
							if ((int)text.length() > 0)
							{
								canBuy = true;
								if(orderInfo.m_price > 0)
								{
									wchar_t strPrice[1024] = {0};
									_stprintf_s(strPrice, 1024, L"%.3f", orderInfo.m_price);
									SetText(childWindowInfo.m_hWnd, strPrice);
								}
							}
						}
						else if (editIndex == 3)
						{
							wchar_t strQty[1024] = {0};
							_stprintf_s(strQty, 1024, L"%d", orderInfo.m_qty);
							SetText(childWindowInfo.m_hWnd, strQty);
						}
						editIndex++;
					}
					else if (childWindowInfo.m_className == L"Button")
					{
						if (childWindowInfo.m_text == L"�����µ�")
						{
							buyButton = childWindowInfo;
						}
					}
				}
				if (canBuy)
				{
					if (orderInfo.m_price > 0)
                    {
						wchar_t strQty[1024] = {0};
						_stprintf_s(strQty, 1024, L"%d", orderInfo.m_qty);
						String newText = strQty;
                        if (newText != GetText(priceHandle))
                        {
                            SetText(priceHandle, newText);
                        }
						MouseEvent(L"SETCURSOR", buyButton.m_rect.left + 5, buyButton.m_rect.top + 5, 0);
                        MouseEvent(L"LEFTDOWN", 0, 0, 0);
                        MouseEvent(L"LEFTUP", 0, 0, 0);
                        Sleep(100);
                        SendKey(13);
                        Sleep(100);
                        SendKey(13);
                        Sleep(100);
                        SendKey(13);
                        Sleep(100);
                        SendKey(13);
                        Sleep(100);
                    }
				}
			}
            break;
        }
    }
	m_orderInfos.clear();
	return 0;
}