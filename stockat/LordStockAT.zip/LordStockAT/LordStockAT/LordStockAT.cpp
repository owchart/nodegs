// gaiaStockAT.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "AutoTrade.h"

int _tmain(int argc, _TCHAR* argv[])
{
	while(true)
	{
		cout << "Enter your input: ";
		string input;
		cin >> input;
		if( input == "exit" )
		{
			break;
		}
		else
		{
			AddOrder("601857", 0, 100);
            AddOrder("600028", 0, 100);
            AddOrder("300059", 0, 100);
            AddOrder("600340", 0, 100);
            StartOrder();
		}
	}
	return 0;
}

