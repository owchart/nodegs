#include "StdAfx.h"
#include "CLRHostProxyWrapper.h"
#include <intrin.h>
#include "CLock.h"

CLock m_Lock;

struct stOnceFlag
{
	stOnceFlag():m_lStatus(0),m_lInit(1){}
	long m_lStatus;
	long m_lInit;
};
//��ʵ������
inline bool CallOnce(stOnceFlag &stFlag){
	if(stFlag.m_lInit == stFlag.m_lStatus)
	{
		return false;
	}

	long lStatus = InterlockedCompareExchange(&stFlag.m_lStatus,stFlag.m_lInit,0);

	_ReadWriteBarrier();

	if(!lStatus)
	{
		return true;
	}
	return false;
}
stOnceFlag	CCLRHostProxyWrapper::g_stOnceFlag;
CCLRHostProxyWrapper* CCLRHostProxyWrapper::g_CLRHostProxyWrapper = NULL;; 
CCLRHostProxyWrapper::CCLRHostProxyWrapper(void):m_sCLRHostProxyType(DEF_FW_VERSION2_0)
{
	m_pCLRHostProxy = nullptr;

	LoadCLR();
}
 
CCLRHostProxyWrapper::~CCLRHostProxyWrapper(void)
{
	delete m_pCLRHostProxy;
	m_pCLRHostProxy = nullptr;
}

CCLRHostProxyWrapper* CCLRHostProxyWrapper::GetInstance()
{
	if (g_CLRHostProxyWrapper)
	{
		return g_CLRHostProxyWrapper;
	}
	m_Lock.Lock();
	if(CallOnce(g_stOnceFlag))
	{
		g_CLRHostProxyWrapper = new CCLRHostProxyWrapper();	
	}
	m_Lock.UnLock();
	return g_CLRHostProxyWrapper;
}
void CCLRHostProxyWrapper::ReleaseInstance()
{
	if (g_CLRHostProxyWrapper)
	{
		delete g_CLRHostProxyWrapper;
	}
}

void CCLRHostProxyWrapper::LoadCLR()
{
	m_pCLRHostProxy = new CCLRHostProxy20;
	DWORD dwRet = m_pCLRHostProxy ->LoadCLR();

	if(dwRet == ERROR_ENVVAR_NOT_FOUND)
	{
		m_sCLRHostProxyType = DEF_FW_VERSION4_0;
		delete m_pCLRHostProxy;
		 
		m_pCLRHostProxy = new CCLRHostProxy;
		m_pCLRHostProxy->LoadCLR();
	}
}

void CCLRHostProxyWrapper::Start( LPCWSTR pwzAssemblyPath, LPCWSTR pwzTypeName, LPCWSTR pwzMethodName, LPCWSTR pwzArgument, DWORD *pReturnValue )
{
	m_pCLRHostProxy ->Start(pwzAssemblyPath,pwzTypeName,pwzMethodName,pwzArgument,pReturnValue);
}

