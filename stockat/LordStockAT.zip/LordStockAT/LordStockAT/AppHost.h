/*****************************************************************************\
*                                                                             *
* AppHost.h -    AppHost functions, types, and definitions                    *
*                                                                             *
*               Version 4.00 ������                                       *
*                                                                             *
*               Copyright (c) 2010-2014, Todd's OwChart. All rights reserved. *
*                                                                             *
*******************************************************************************/

#ifndef __AppHost_H__
#define __AppHost_H__
#pragma once
#include "stdafx.h"

class AppHost
{
public:
	AppHost();
	virtual ~AppHost();
public:
	static void SendKey(String cmd);
};

#endif